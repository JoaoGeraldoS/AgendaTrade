package com.example.agendatrade.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.agendatrade.data.dao.ActiveDao
import com.example.agendatrade.data.dao.DailyPerformaceDao
import com.example.agendatrade.data.dao.MarketDao // Importe o MarketDao
import com.example.agendatrade.data.dao.TaskDao
import com.example.agendatrade.data.dao.TradeDao
import com.example.agendatrade.data.dao.UserDao
import com.example.agendatrade.data.enums.MarketType
import com.example.agendatrade.data.models.*
import com.example.agendatrade.utils.Converters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Provider

@Database(entities = [Task::class, Active::class, Market::class, Trade::class, DailyPerformace::class, User::class], version = 12)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun activeDao(): ActiveDao
    abstract fun tradeDao(): TradeDao
    abstract fun dailyPerformaceDao(): DailyPerformaceDao
    abstract fun userDao(): UserDao
    abstract fun marketDao(): MarketDao // Adicione este método

    class MarketDatabaseCallback(
        private val scope: CoroutineScope,
        private val activeDaoProvider: Provider<ActiveDao>,
        private val marketDaoProvider: Provider<MarketDao> // Corrija o tipo de injeção
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                val marketDao = marketDaoProvider.get()
                val activeDao = activeDaoProvider.get()

                // O resto do código é o mesmo
                val forexMarket = Market(type = MarketType.FOREX)
                val stockMarket = Market(type = MarketType.STOCK)
                val futuresMarket = Market(type = MarketType.FUTURES)
                val optionsMarket = Market(type = MarketType.OPTIONS)
                val forexId = marketDao.addMarket(forexMarket)
                val stockId = marketDao.addMarket(stockMarket)
                val futuresId = marketDao.addMarket(futuresMarket)
                val optionsId = marketDao.addMarket(optionsMarket)

                val initialActives = listOf(
                    Active(name = "EUR/USD", marketId = forexId, baseCurrency = "EUR", quoteCurrency = "USD"),
                    Active(name = "USD/JPY", marketId = forexId, baseCurrency = "USD", quoteCurrency = "JPY"),
                    Active(name = "GBP/USD", marketId = forexId, baseCurrency = "GBP", quoteCurrency = "USD"),
                    Active(name = "USD/CAD", marketId = forexId, baseCurrency = "USD", quoteCurrency = "CAD"),
                    Active(name = "PETR4", marketId = stockId, isFractionalMarket = true),
                    Active(name = "VALE3", marketId = stockId, isFractionalMarket = true),
                    Active(name = "ITUB4", marketId = stockId, isFractionalMarket = true),
                    Active(name = "BBDC4", marketId = stockId, isFractionalMarket = true),
                    Active(name = "WIN$", marketId = futuresId, pointValue = 0.20),
                    Active(name = "WDO$", marketId = futuresId, pointValue = 10.00),
                    Active(name = "DOL", marketId = futuresId, pointValue = 50.00),
                    Active(name = "CCM", marketId = futuresId, pointValue = 450.00),
                    Active(name = "BGI", marketId = futuresId, pointValue = 330.00)
                )

                activeDao.insertAll(initialActives)
            }
        }
    }
}