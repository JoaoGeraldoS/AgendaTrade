package com.example.agendatrade.domain.usecase.task

import com.example.agendatrade.data.models.Task
import com.example.agendatrade.data.repositories.TaskRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ReadTaskUseCase @Inject constructor(private val taskRepository: TaskRepository) {
    operator fun invoke(): Flow<List<Task>> = taskRepository.readAllTask()
}