package com.example.agendatrade.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "daily_performaces")
data class DailyPerformace(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Date,
    val totalProfitLoss: Double
)
