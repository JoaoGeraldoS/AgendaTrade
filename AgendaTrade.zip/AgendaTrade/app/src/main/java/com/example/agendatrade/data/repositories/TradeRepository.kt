package com.example.agendatrade.data.repositories

import com.example.agendatrade.data.dao.TradeDao
import com.example.agendatrade.data.dto.TradeAndActiveDto
import com.example.agendatrade.data.models.Trade
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class TradeRepository @Inject constructor(private val dao: TradeDao) {

    fun readAllTrade(): Flow<List<TradeAndActiveDto>> = dao.getAllTradesWithActive()

    fun readByIdTrade(id: Long): Flow<TradeAndActiveDto?> = dao.getByIdTradesWithActive(id)


    suspend fun createTrade(trade: Trade) = dao.addTrade(trade)
    suspend fun updateTrade(trade: Trade) = dao.updateTrade(trade)
    suspend fun deleteTrade(trade: Trade) = dao.deleteTrade(trade)
    suspend fun deleteTradeById(tradeId: Long) = dao.deleteTradeById(tradeId)


}