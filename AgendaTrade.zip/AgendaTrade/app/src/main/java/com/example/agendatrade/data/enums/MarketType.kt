package com.example.agendatrade.data.enums

enum class MarketType {
    FOREX,
    STOCK, // Ações
    FUTURES, // Futuros
    OPTIONS // Opções
    // Adicione outros tipos conforme necessário
}