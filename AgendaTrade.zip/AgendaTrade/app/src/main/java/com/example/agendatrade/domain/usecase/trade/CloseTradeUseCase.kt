package com.example.agendatrade.domain.usecase.trade

import android.util.Log
import com.example.agendatrade.data.enums.StatusTrade
import com.example.agendatrade.data.models.DailyPerformace // Importe DailyPerformance
import com.example.agendatrade.data.repositories.DailyPerformanceRepository // Importe o novo repo
import com.example.agendatrade.data.repositories.TradeRepository
import kotlinx.coroutines.flow.firstOrNull
import java.util.Calendar
import java.util.Date
import javax.inject.Inject

class CloseTradeUseCase @Inject constructor(
    private val tradeRepository: TradeRepository,
    private val tradeProfitLossCalculator: TradeProfitLossCalculator,
    private val dailyPerformanceRepository: DailyPerformanceRepository // Injete o novo repositório
) {
    /**
     * Fecha um trade existente, calculando seu lucro/prejuízo e atualizando seu status e data de fechamento.
     * Também atualiza a performance diária acumulada.
     *
     * @param tradeId O ID do trade a ser fechado.
     * @param outPrice O preço de saída final do trade.
     * @throws IllegalArgumentException se o trade não for encontrado.
     * @throws IllegalStateException se o cálculo de lucro/prejuízo falhar.
     */
    suspend operator fun invoke(tradeId: Long, outPrice: Double): Double {
        val tradeAndActiveDtoToClose = tradeRepository.readByIdTrade(tradeId).firstOrNull()

        if (tradeAndActiveDtoToClose == null) {
            throw IllegalArgumentException("Trade com ID $tradeId não encontrado para fechar.")
        }

        val tradeToClose = tradeAndActiveDtoToClose.trade

        if (tradeToClose.status == StatusTrade.CLOSED) {
            Log.w("CloseTradeUseCase", "Trade com ID $tradeId já está fechado. Nenhuma ação necessária.")
            return 0.0
        }

        try {
            val tempTradeForCalculation = tradeToClose.copy(outPrice = outPrice)
            val calculatedProfitLoss = tradeProfitLossCalculator.calculateTradeProfitLoss(tempTradeForCalculation)

            val closedTrade = tradeToClose.copy(
                outPrice = outPrice,
                profitLoss = calculatedProfitLoss,
                status = StatusTrade.CLOSED,
                closeDate = Date()
            )

            // 1. Atualize o trade no banco de dados
            tradeRepository.updateTrade(closedTrade)
            Log.d("CloseTradeUseCase", "Trade $tradeId fechado com sucesso. Lucro/Prejuízo: $calculatedProfitLoss")

            // --- NOVO: Atualizar a performance diária ---
            updateDailyPerformance(closedTrade.closeDate!!, calculatedProfitLoss) // Usa !! pois closeDate foi setado

            return calculatedProfitLoss

        } catch (e: Exception) {
            Log.e("CloseTradeUseCase", "Erro ao fechar trade $tradeId: ${e.message}", e)
            throw IllegalStateException("Falha ao fechar trade: ${e.message}", e)
        }
    }

    // Função auxiliar para atualizar a performance diária
   suspend fun updateDailyPerformance(date: Date, profitLoss: Double) {
        // Obter a data sem informações de hora/minuto/segundo
        val calendar = Calendar.getInstance()
        calendar.time = date
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val dailyKeyDate = calendar.time // Esta será a chave para o dia

        // Tenta obter a performance diária existente para esta data
        val existingDailyPerformance =dailyPerformanceRepository.getDailyPerformanceByExactDate(dailyKeyDate).firstOrNull()

        if (existingDailyPerformance != null) {
            // Se já existe, atualiza o total
            val updatedTotal = existingDailyPerformance.totalProfitLoss + profitLoss
            val updatedDaily = existingDailyPerformance.copy(totalProfitLoss = updatedTotal)
            dailyPerformanceRepository.insertOrUpdateDailyPerformance(updatedDaily)
            Log.d("CloseTradeUseCase", "Daily Performance para ${dailyKeyDate} atualizada. Novo total: $updatedTotal")
        } else {
            // Se não existe, cria um novo registro
            val newDaily = DailyPerformace(date = dailyKeyDate, totalProfitLoss = profitLoss)
            dailyPerformanceRepository.insertOrUpdateDailyPerformance(newDaily)
            Log.d("CloseTradeUseCase", "Nova Daily Performance para ${dailyKeyDate} criada. Total: $profitLoss")
        }
    }
}