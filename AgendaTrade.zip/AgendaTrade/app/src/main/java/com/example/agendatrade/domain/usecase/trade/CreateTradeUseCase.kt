package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.data.repositories.TradeRepository
import javax.inject.Inject

class CreateTradeUseCase @Inject constructor(
    private val repository: TradeRepository,
    private val tradeProfitLossCalculator: TradeProfitLossCalculator
) {
    suspend operator fun invoke(trade: Trade) {
        val calculatedProfitLoss = tradeProfitLossCalculator.calculateTradeProfitLoss(trade)

        // Crie uma cópia do trade com o profitLoss calculado
        val tradeToSave = trade.copy(profitLoss = calculatedProfitLoss)

        // Agora salve o trade atualizado no repositório
        repository.createTrade(tradeToSave)
    }
}