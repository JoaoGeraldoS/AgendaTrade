package com.example.agendatrade.ui.theme

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun customTextFieldColors() = TextFieldDefaults.colors(
    // Cores de fundo (ContainerColor) - Transparente para remover a "caixa"
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    errorContainerColor = Color.Transparent,

    // Cores da linha inferior (Indicator)
    focusedIndicatorColor = MaterialTheme.colorScheme.primary, // Linha primária quando focado
    unfocusedIndicatorColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), // Linha mais clara quando não focado
    disabledIndicatorColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
    errorIndicatorColor = MaterialTheme.colorScheme.error,

    // Cores do label (texto flutuante)
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
    disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
    errorLabelColor = MaterialTheme.colorScheme.error,

    // Cores do texto de entrada
    focusedTextColor = MaterialTheme.colorScheme.onSurface,
    unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
    disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
    errorTextColor = MaterialTheme.colorScheme.error,

    // Cor do cursor
    cursorColor = MaterialTheme.colorScheme.primary
)