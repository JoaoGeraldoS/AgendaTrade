package com.example.agendatrade.di

import com.example.agendatrade.data.repositories.ActiveRepository
import com.example.agendatrade.data.repositories.DailyPerformanceRepository
import com.example.agendatrade.data.repositories.TaskRepository
import com.example.agendatrade.data.repositories.TradeRepository
import com.example.agendatrade.domain.usecase.active.ActiveUseCase
import com.example.agendatrade.domain.usecase.task.AddTaskUseCase
import com.example.agendatrade.domain.usecase.active.CreateActiveUseCase
import com.example.agendatrade.domain.usecase.active.DeleteActiveUseCase
import com.example.agendatrade.domain.usecase.active.PopulateActiveUseCase
import com.example.agendatrade.domain.usecase.task.DeleteTaskUseCase
import com.example.agendatrade.domain.usecase.active.ReadActiveAndMarketByIdUseCase
import com.example.agendatrade.domain.usecase.active.ReadActiveByIdUseCase
import com.example.agendatrade.domain.usecase.active.ReadAllActiveAndMarketsUseCase
import com.example.agendatrade.domain.usecase.task.ReadByIdTaskUseCase
import com.example.agendatrade.domain.usecase.task.ReadTaskUseCase
import com.example.agendatrade.domain.usecase.active.UpdateActiveUseCase
import com.example.agendatrade.domain.usecase.market.CreateMarketUseCase
import com.example.agendatrade.domain.usecase.market.DeleteMarketUseCase
import com.example.agendatrade.domain.usecase.market.MarketUseCase
import com.example.agendatrade.domain.usecase.market.ReadAllMarketUseCase
import com.example.agendatrade.domain.usecase.market.UpdateMarketUseCase
import com.example.agendatrade.domain.usecase.task.TaskUseCase
import com.example.agendatrade.domain.usecase.task.UpdateTaskUseCase
import com.example.agendatrade.domain.usecase.trade.CloseTradeUseCase
import com.example.agendatrade.domain.usecase.trade.CreateTradeUseCase
import com.example.agendatrade.domain.usecase.trade.DeleteTradeByIdUseCase
import com.example.agendatrade.domain.usecase.trade.DeleteTradeUseCase
import com.example.agendatrade.domain.usecase.trade.ReadAllTradeUseCase
import com.example.agendatrade.domain.usecase.trade.ReadByIdTradeUseCase
import com.example.agendatrade.domain.usecase.trade.TradeProfitLossCalculator
import com.example.agendatrade.domain.usecase.trade.TradeUseCase
import com.example.agendatrade.domain.usecase.trade.UpdateTradeUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides
    fun provideTaskUseCase(repository: TaskRepository): TaskUseCase {
        return TaskUseCase(
            readTaskUseCase = ReadTaskUseCase(repository),
            addTaskUseCase = AddTaskUseCase(repository),
            readByIdTaskUseCase = ReadByIdTaskUseCase(repository),
            updateTaskUseCase = UpdateTaskUseCase(repository),
            deleteTaskUseCase = DeleteTaskUseCase(repository)
        )
    }

    @Provides
    fun provideActiveUseCase(repository: ActiveRepository): ActiveUseCase {
        return ActiveUseCase(
            createActiveUseCase = CreateActiveUseCase(repository),
            readAllActiveAndMarketsUseCase = ReadAllActiveAndMarketsUseCase(repository),
            readActiveAndMarketByIdUseCase = ReadActiveAndMarketByIdUseCase(repository),
            readActiveByIdUseCase = ReadActiveByIdUseCase(repository),
            updateActiveUseCase = UpdateActiveUseCase(repository),
            deleteActiveUseCase = DeleteActiveUseCase(repository),
            populateActiveUseCase = PopulateActiveUseCase(repository)
        )
    }

    @Provides
    fun provideMarketUseCase(repository: ActiveRepository): MarketUseCase {
        return MarketUseCase(
            createMarketUseCase = CreateMarketUseCase(repository),
            updateMarketUseCase = UpdateMarketUseCase(repository),
            deleteMarketUseCase = DeleteMarketUseCase(repository),
            readAllMarketUseCase = ReadAllMarketUseCase(repository)
        )
    }

    @Provides
    fun provideTradeUseCase(
        repository: TradeRepository,
        activeRepository: ActiveRepository,
        dailyPerformanceRepository: DailyPerformanceRepository
    )
    : TradeUseCase {

        val tradeProfitLossCalculator = TradeProfitLossCalculator(repository,activeRepository)

        val createTradeUseCase = CreateTradeUseCase(repository, tradeProfitLossCalculator)

        return TradeUseCase(
            readAllTradeUseCase = ReadAllTradeUseCase(repository),
            readByIdTradeUseCase = ReadByIdTradeUseCase(repository),
            createTradeUseCase = createTradeUseCase,
            deleteTradeUseCase = DeleteTradeUseCase(repository),
            tradeProfitLossCalculator = tradeProfitLossCalculator,
            closeTradeUseCase = CloseTradeUseCase(repository, tradeProfitLossCalculator, dailyPerformanceRepository ),
            deleteTradeByIdUseCase = DeleteTradeByIdUseCase(repository),
            updateTradeUseCase = UpdateTradeUseCase(repository),

        )
    }
}