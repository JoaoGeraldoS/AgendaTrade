package com.example.agendatrade.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.agendatrade.data.dto.ActiveAndMarketDto
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.models.Market
import kotlinx.coroutines.flow.Flow

@Dao
interface ActiveDao {

    // Operações Ativo

    @Query("SELECT * FROM actives")
    fun getAllActives(): Flow<List<Active>>

    @Query("SELECT * FROM actives WHERE id = :activeId LIMIT 1")
    fun getActiveById(activeId: Long): Flow<Active?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addActive(active: Active): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(actives: List<Active>)

    @Update
    suspend fun upActive(active: Active)

    @Delete
    suspend fun delActive(active: Active)

    // Ativo com Mercado

    @Transaction
    @Query("SELECT * FROM actives WHERE id = :activeId LIMIT 1")
    fun getActiveAndMarketById(activeId: Long): Flow<ActiveAndMarketDto?>

    @Transaction
    @Query("SELECT * FROM actives")
    fun getAllActiveAndMarket(): Flow<List<ActiveAndMarketDto>>

    // Operações Mercado

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addMarket(market: Market): Long

    @Update
    suspend fun upMarket(market: Market)

    @Delete
    suspend fun delMarket(market: Market)

    // Buscar um Mercado por ID
    @Query("SELECT * FROM markets WHERE id = :marketId LIMIT 1")
    fun getMarketById(marketId: Long): Flow<Market?>

    // Buscar todos os Mercados
    @Query("SELECT * FROM markets")
    fun getAllMarkets(): Flow<List<Market>>
}