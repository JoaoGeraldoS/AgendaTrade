package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.enums.MarketType
import com.example.agendatrade.data.enums.OperationType
import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.data.repositories.ActiveRepository
import com.example.agendatrade.data.repositories.TradeRepository
import com.example.agendatrade.utils.ForexUtils
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import kotlin.math.pow


class TradeProfitLossCalculator @Inject constructor(
    private val tradeRepository: TradeRepository, // Mantido, mas não usado diretamente aqui
    private val activeRepository: ActiveRepository
) {
    suspend fun calculateTradeProfitLoss(trade: Trade): Double {

        val inputPrice = trade.inputPrice
        val outPrice = trade.outPrice
        val operationType = trade.operationType


        // 1. Obter o Ativo completo
        val active = activeRepository.getActiveById(trade.activeId).firstOrNull()
            ?: throw IllegalArgumentException("Ativo não encontrado para o trade com ID: ${trade.activeId}")

        // 2. Obter o Mercado do Ativo (para determinar a lógica de cálculo)
        val market = activeRepository.getMarketById(active.marketId).firstOrNull()
            ?: throw IllegalArgumentException("Mercado não encontrado para o ativo com ID: ${active.marketId}")



        val adjustedPriceDifference = when (operationType) {
            OperationType.BUY -> outPrice - inputPrice // Lucro se outPrice > inputPrice
            OperationType.SELL -> inputPrice - outPrice // Lucro se inputPrice > outPrice
            // Adicione outros tipos de operação se existirem, ou use um 'else' para um tratamento genérico
            else -> throw IllegalArgumentException("Tipo de operação desconhecido: $operationType")
        }


        val quantity = trade.quantity



        return when (market.type) {
            MarketType.FOREX -> {
                val pipValuePerUnit = ForexUtils.calculatePipValuePerUnit(active.name)
                val pipDecimalPlaces = ForexUtils.getPipDecimalPlaces(active.name)
                val contractSize = ForexUtils.getContractSize(active.name)
                val pipValueBase = 10.0.pow(-pipDecimalPlaces.toDouble())
                val pipValuePerStandardLot = contractSize * pipValueBase
                val totalPipsDifference = adjustedPriceDifference / pipValueBase

                val total: Double = totalPipsDifference * pipValuePerUnit * quantity

                return total

            }
            MarketType.STOCK -> {
                val total: Double = adjustedPriceDifference  * quantity
                return total
            }
            MarketType.FUTURES -> {
                val assetName = active.name.uppercase()
                val pointValue: Double
                val tickSize: Double

                val futuresConfig = when {
                    // Mini Dólar
                    assetName.contains("WDO") -> Pair(10.0, 0.5)
                    // Dólar Cheio
                    assetName.contains("DOL") -> Pair(50.0, 0.5)
                    // Mini Índice
                    assetName.contains("WIN") -> Pair(0.20, 5.0)
                    // Contrato de Milho
                    assetName.contains("CCM") -> Pair(450.0, 50.0)
                    // Contrato de Boi Gordo
                    assetName.contains("BGI") -> Pair(330.0, 0.05)
                    // Retorno padrão para qualquer outro ativo futuro não mapeado
                    else -> Pair(0.0, 0.0)
                }
                pointValue = futuresConfig.first
                tickSize = futuresConfig.second


                val total: Double = adjustedPriceDifference * pointValue * quantity
                total
            }
            MarketType.OPTIONS -> {
                val optionMultiplier = 100.0
                val total: Double = adjustedPriceDifference * quantity * optionMultiplier
                return total
            }
            else -> {
                val total: Double = adjustedPriceDifference * quantity
                return total
            }
        }
    }
}