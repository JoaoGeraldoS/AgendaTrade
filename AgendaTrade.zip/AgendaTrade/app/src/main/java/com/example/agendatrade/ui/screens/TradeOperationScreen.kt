package com.example.agendatrade.ui.screens

import android.app.DatePickerDialog
import android.util.Log
import android.widget.DatePicker
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agendatrade.data.dto.ActiveAndMarketDto
import com.example.agendatrade.data.enums.OperationType
import com.example.agendatrade.data.enums.StatusTrade
import com.example.agendatrade.data.models.Market
import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.ui.theme.customTextFieldColors
import com.example.agendatrade.ui.viewmodels.ActiveViewModel
import com.example.agendatrade.ui.viewmodels.TradeViewModel
import com.example.agendatrade.utils.DismissKeyboardOnOutsideClick
import com.example.agendatrade.utils.toFriendlyName
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


// --- Composable da Tela de Registro de Trade ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterTradeScreen(
    navController: NavController,
    activeViewModel: ActiveViewModel = hiltViewModel(),
    tradeViewModel: TradeViewModel = hiltViewModel()
) {


    val allActiveAndMarket by activeViewModel.allActiveAndMarketDto.collectAsState()
    val allMarkets by activeViewModel.allMarkets.collectAsState()

    // Estados para os campos do formulário
    var selectedActiveAndMarketDto by remember { mutableStateOf<ActiveAndMarketDto?>(null) }
    var operationType by remember { mutableStateOf(OperationType.BUY) }
    var operationDate by remember { mutableStateOf(Calendar.getInstance()) }
    var inputPrice by remember { mutableStateOf("0.00") }
    var outPrice by remember { mutableStateOf("0.00") }
    var quantity by remember { mutableStateOf("0.00") }
    var status by remember { mutableStateOf(StatusTrade.OPEN) }
    var selectedMarket by remember { mutableStateOf<Market?>(null) }

    val profitLoss = remember(inputPrice, outPrice, quantity) {
        val input = inputPrice.toDoubleOrNull() ?: 0.0
        val output = outPrice.toDoubleOrNull() ?: 0.0
        val qty = quantity.toDoubleOrNull() ?: 0.00
        (output - input) * qty
    }

    // Estados para os Dropdown Menus
    var operationTypeExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }
    var activeExpanded by remember { mutableStateOf(false) }
    var marketExpanded by remember { mutableStateOf(false) }


    LaunchedEffect(selectedMarket, allActiveAndMarket) {
        selectedActiveAndMarketDto = null

    }

    val filterdActives = remember(selectedMarket, allActiveAndMarket) {
        if(selectedMarket == null) {
            emptyList()
        } else {
            allActiveAndMarket.filter { it.active.marketId == selectedMarket!!.id }
        }
    }

    // --- Instância das cores customizadas ---
    val customColors = customTextFieldColors()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier.clickable { navController.popBackStack() }.size(30.dp)
                    )
                }
            )
        }
    ) { paddingValues ->

        DismissKeyboardOnOutsideClick {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp), // Padding para os lados e cima/baixo
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                // Mercado
                ExposedDropdownMenuBox(
                    expanded = marketExpanded,
                    onExpandedChange = { marketExpanded = !marketExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField( // Usando TextField com o estilo sublinhado
                        value = selectedMarket?.type?.toFriendlyName() ?: "Selecione um Mercado",
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Mercado") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = marketExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customColors
                    )
                    ExposedDropdownMenu(
                        expanded = marketExpanded,
                        onDismissRequest = { marketExpanded = false }
                    ) {



                        // Itens da lista de mercados existentes
                        allMarkets.forEach { marketOption ->
                            DropdownMenuItem(
                                text = { Text(text = marketOption.type.toFriendlyName()) },
                                onClick = {
                                    selectedMarket = marketOption
                                    marketExpanded = false
                                }
                            )
                        }

                        // Separador opcional para distinguir a opção de adicionar
                        if (allMarkets.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                    }
                }


                // --- Campo: Ativo (Dropdown) ---
                ExposedDropdownMenuBox(
                    expanded = activeExpanded,
                    onExpandedChange = { activeExpanded = !activeExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = selectedActiveAndMarketDto?.active?.name ?: "Selecione um Ativo", // Updated initial text
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Ativo") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = activeExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customColors
                    )
                    ExposedDropdownMenu(
                        expanded = activeExpanded,
                        onDismissRequest = { activeExpanded = false }
                    ) {
                        if (filterdActives.isEmpty()) {
                            // Display message if no actives are loaded
                            DropdownMenuItem(
                                text = { Text("Nenhum ativo disponível") },
                                onClick = { /* No action, just informational */ },
                                enabled = false // Make it non-clickable
                            )
                            Divider() // Separator for visual clarity
                        }

                        filterdActives.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(text = selectionOption.active.name) },
                                onClick = {
                                    selectedActiveAndMarketDto = selectionOption
                                    activeExpanded = false
                                }
                            )
                        }

                        // --- Add New Active Option ---
                        Divider() // Separator
                        DropdownMenuItem(
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Adicionar Novo Ativo")
                                    Text("Adicionar Novo Ativo")
                                }
                            },
                            onClick = {
                                activeExpanded = false
                                navController.navigate("active_register_screen")
                            }
                        )
                    }
                }

                // --- Campo: OperationType (Dropdown) ---
                ExposedDropdownMenuBox(
                    expanded = operationTypeExpanded,
                    onExpandedChange = { operationTypeExpanded = !operationTypeExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = operationType.toFriendlyName(),
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Tipo de Operação") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = operationTypeExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customColors
                    )
                    ExposedDropdownMenu(
                        expanded = operationTypeExpanded,
                        onDismissRequest = { operationTypeExpanded = false }
                    ) {
                        OperationType.entries.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(text = selectionOption.toFriendlyName()) },
                                onClick = {
                                    operationType = selectionOption
                                    operationTypeExpanded = false
                                }
                            )
                        }
                    }
                }

                // --- Campo: Data da Operação ---
                TextField(
                    value = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(operationDate.time),
                    onValueChange = { /* A data seria alterada via DatePicker */ },
                    label = { Text("Data da Operação") },
                    readOnly = true,
                    trailingIcon = {
                        val mContext = LocalContext.current
                        val mYear = operationDate.get(Calendar.YEAR)
                        val mMonth = operationDate.get(Calendar.MONTH)
                        val mDay = operationDate.get(Calendar.DAY_OF_MONTH)

                        val mDatePickerDialog = DatePickerDialog(
                            mContext,
                            { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
                                val newCalendar = Calendar.getInstance()
                                newCalendar.set(year, month, dayOfMonth)
                                operationDate = newCalendar
                            }, mYear, mMonth, mDay
                        )

                        Icon(
                            Icons.Default.DateRange,
                            contentDescription = "Selecionar Data",
                            modifier = Modifier.clickable {
                                mDatePickerDialog.show()
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = customColors
                )

                // --- Campo: InputPrice ---
                TextField(
                    value = inputPrice,
                    onValueChange = { inputPrice = it },
                    label = { Text("Preço (Pontos) de Entrada") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customColors
                )

                // --- Campo: OutPrice ---
                TextField(
                    value = outPrice,
                    onValueChange = { outPrice = it },
                    label = { Text("Preço (Pontos) de Saída") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customColors
                )

                // --- Campo: Quantity ---
                TextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("Quantidade") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customColors
                )

                // --- Campo: Status (Dropdown) ---
                ExposedDropdownMenuBox(
                    expanded = statusExpanded,
                    onExpandedChange = { statusExpanded = !statusExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = status.toFriendlyName(),
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Status") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customColors
                    )
                    ExposedDropdownMenu(
                        expanded = statusExpanded,
                        onDismissRequest = { statusExpanded = false }
                    ) {
                        StatusTrade.entries.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(text = selectionOption.toFriendlyName()) },
                                onClick = {
                                    status = selectionOption
                                    statusExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // --- Campo: Profit/Loss (Apenas para visualização) ---
                Text(
                    text = "Profit/Loss: ${String.format("%.2f", profitLoss)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = when {
                        profitLoss > 0 -> Color(0xFF4CAF50) // Verde para lucro
                        profitLoss < 0 -> Color(0xFFF44336) // Vermelho para perda
                        else -> MaterialTheme.colorScheme.onSurface // Cor neutra para zero
                    },
                    modifier = Modifier.padding(vertical = 8.dp)
                )


                // Botão para Salvar
                Button(
                    onClick = {
                        if (selectedMarket == null) {
                            println("Erro: Por favor, selecione um mercado.")
                            // TODO: Mostrar um Toast ou Snackbar para o usuário
                            return@Button // Impede o salvamento
                        }
                        val selectedDate = operationDate.time
                        // **Validação para o Ativo**
                        selectedActiveAndMarketDto?.let { activeAndMarket ->
                            val newTrade = Trade(
                                activeId = activeAndMarket.active.id, // Corrigido para activeId
                                operationType = operationType,
                                operationDate = selectedDate,
                                inputPrice = inputPrice.toDoubleOrNull() ?: 0.0,
                                outPrice = outPrice.toDoubleOrNull() ?: 0.0,
                                quantity = quantity.toDoubleOrNull() ?: 0.0,
                                status = status,
                                profitLoss = 0.0
                            )

                            tradeViewModel.addTrade(newTrade, closeDate = selectedDate)
                            navController.popBackStack()
                        } ?: run {
                            println("Erro: Nenhum ativo selecionado para o trade.")

                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Salvar Trade")
                }
            }
        }


    }
}



@Preview(showBackground = true, widthDp = 320)
@Composable
fun PreviewRegisterTradeScreen() {
    MaterialTheme {
        RegisterTradeScreen(navController = NavController(LocalContext.current))
    }
}