package com.example.agendatrade.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agendatrade.ui.preferences.AppPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val appPreferences: AppPreferences
) : ViewModel() {

    fun saveOnboardingData(
        userName: String,
        tradeProfile: String,
        selectedMarkets: List<String>,
        currency: String
    ) {
        viewModelScope.launch {
            // Apenas salva as preferências do usuário, nada mais.
            appPreferences.setUserName(userName)
            appPreferences.setTradeProfile(tradeProfile)
            appPreferences.setCurrency(currency)
            appPreferences.setOnboardingCompleted(true)
        }
    }
}