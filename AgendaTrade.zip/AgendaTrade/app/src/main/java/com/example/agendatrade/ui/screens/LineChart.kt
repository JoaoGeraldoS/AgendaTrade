@file:Suppress("MagicNumber")

package com.example.agendatrade.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

data class ChartEntry(
    val label: String,
    val value: Float
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LineChart(
    data: List<ChartEntry>,
    modifier: Modifier = Modifier,
    minY: Float? = null,
    maxY: Float? = null,
    ySteps: Int = 5,
    padding: Dp = 16.dp,
    lineWidth: Dp = 2.dp,
    pointRadius: Dp = 3.dp,
    showPoints: Boolean = true,
    showGrid: Boolean = true,
    gridAlpha: Float = 0.15f,
    areaFillAlpha: Float = 0.25f,
    animate: Boolean = true,
    initialPointColor: Color = Color.Unspecified
) {
    require(data.size >= 0) { "Forneça pelo menos 2 pontos para o gráfico." }

    if (data.isEmpty()) {
        Text(
            text = "Nenhum dado para exibir o gráfico.",
            modifier = modifier,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        return
    }

    val textMeasurer = rememberTextMeasurer()
    val density = LocalDensity.current

    val values = data.map { it.value }
    val yMin = minY ?: values.minOrNull()!!
    val yMax = maxY ?: values.maxOrNull()!!
    val yRange = (yMax - yMin).takeIf { it > 0f } ?: 1f


    val firstValue = data.first().value
    val lastValue = data.last().value

    val primaryChartColor = when {
        lastValue > firstValue -> Color(0xFF4CAF50) // Verde: Tendência positiva
        lastValue < firstValue -> Color(0xFFF44336) // Vermelho: Tendência negativa
        else -> Color(0xFF2196F3) // Azul: Empate (valores iguais)
    }

    // Cores auxiliares do tema
    val surfaceColor = MaterialTheme.colorScheme.surface
    val onPrimaryColor = MaterialTheme.colorScheme.onPrimary
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface
    val labelTextColor = onSurfaceColor.copy(alpha = 0.6f)

    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val reveal by animateFloatAsState(
        targetValue = if (animate) 1f else 1f,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "reveal_animation"
    )

    val stroke = with(density) { lineWidth.toPx() }
    val pointR = with(density) { pointRadius.toPx() }
    val pad = with(density) { padding.toPx() }

    val onGesture: suspend PointerInputScope.() -> Unit = {
        awaitEachGesture {
            val down = awaitFirstDown()
            var current = down.position
            fun indexAt(x: Float, width: Int, count: Int): Int {
                val innerW = width - pad * 2
                val stepX = innerW / (count - 1).coerceAtLeast(1)
                val clamped = current.x.coerceIn(pad, width - pad)
                return ((clamped - pad) / stepX).toInt().coerceIn(0, count - 1)
            }
            selectedIndex = null
            drag(down.id) { change ->
                current = change.position
                change.consume()
                selectedIndex = indexAt(current.x, size.width, data.size)
            }
        }
    }

    Canvas(
        modifier = modifier
            .background(Color.Unspecified)
            .pointerInput(data) { onGesture() }
    ) {


        val w = size.width
        val h = size.height
        val innerW = w - pad * 2
        val innerH = h - pad * 2

        fun xAt(index: Int) = pad + innerW * (index / (data.size - 1f))
        fun yAt(value: Float) = pad + innerH - ((value - yMin) / yRange) * innerH

        val points = data.indices.map { i -> Offset(xAt(i), yAt(data[i].value)) }

        val path = Path().apply {
            reset()
            moveTo(points.first().x, points.first().y)
            for (i in 1 until points.size) {
                val prev = points[i - 1]
                val curr = points[i]
                val prevPrev = points.getOrNull(i - 2) ?: prev
                val next = points.getOrNull(i + 1) ?: curr

                val c1x = prev.x + (curr.x - prevPrev.x) / 6f
                val c1y = prev.y + (curr.y - prevPrev.y) / 6f
                val c2x = curr.x - (next.x - prev.x) / 6f
                val c2y = curr.y - (next.y - prev.y) / 6f

                cubicTo(c1x, c1y, c2x, c2y, curr.x, curr.y)
            }
        }

        if (showGrid) {
            val gridColor = onSurfaceColor.copy(alpha = gridAlpha)
            val stepY = innerH / ySteps
            repeat(ySteps + 1) { i ->
                val y = pad + i * stepY
                drawLine(
                    color = gridColor,
                    start = Offset(pad, y),
                    end = Offset(w - pad, y),
                    strokeWidth = 1f
                )
            }
        }

        val areaPath = Path().apply {
            addPath(path)
            lineTo(points.last().x, h - pad)
            lineTo(points.first().x, h - pad)
            close()
        }
        val gradient = Brush.verticalGradient(
            colors = listOf(
                primaryChartColor.copy(alpha = areaFillAlpha), // Usa a cor principal do gráfico
                Color.Transparent
            ),
            startY = pad,
            endY = h - pad
        )

        withTransform({
            clipRect(left = 0f, top = 0f, right = w * reveal, bottom = h)
        }) {
            drawPath(areaPath, brush = gradient)

            drawPath(
                path = path,
                color = primaryChartColor, // Usa a cor principal do gráfico
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }

        if (showPoints) {
            points.forEachIndexed { index, p ->
                if (p.x <= w * reveal) {
                    // Decide a cor do círculo do ponto
                    val circleColor = if (index == 0 && initialPointColor != Color.Unspecified) {
                        initialPointColor // Se initialPointColor foi especificado e é o primeiro ponto
                    } else {
                        primaryChartColor // Caso contrário, usa a cor principal do gráfico
                    }

                    drawCircle(
                        color = circleColor,
                        radius = pointR,
                        center = p
                    )
                    drawCircle(
                        color = surfaceColor,
                        radius = pointR / 2.2f,
                        center = p
                    )
                }
            }
        }

        val labelStyle = TextStyle(
            color = labelTextColor,
            fontSize = 10.sp
        )
        repeat(ySteps + 1) { i ->
            val value = yMin + (yRange / ySteps) * (ySteps - i)
            val text = "%,.1f".format(value)
            val result = textMeasurer.measure(text = text, style = labelStyle)
            drawText(
                textLayoutResult = result,
                topLeft = Offset(
                    x = pad / 4f,
                    y = pad + i * (innerH / ySteps) - result.size.height / 2f
                )
            )
        }

        selectedIndex?.let { idx ->
            val p = points[idx]
            val entry = data[idx]

            val guideColor = primaryChartColor.copy(alpha = 0.35f) // Usa a cor principal do gráfico
            drawLine(
                color = guideColor,
                start = Offset(p.x, pad),
                end = Offset(p.x, h - pad),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 14f), 0f)
            )

            // Marcador do tooltip
            val tooltipPointColor = if (idx == 0 && initialPointColor != Color.Unspecified) {
                initialPointColor
            } else {
                primaryChartColor
            }

            drawCircle(
                color = tooltipPointColor,
                radius = pointR * 1.3f,
                center = p
            )
            drawCircle(
                color = surfaceColor,
                radius = pointR * 0.75f,
                center = p
            )

            val title = entry.label
            val valueTxt = "%,.2f".format(entry.value)
            val titleLayout = textMeasurer.measure(
                text = title,
                style = TextStyle(
                    color = onPrimaryColor,
                    fontSize = 11.sp
                )
            )
            val valueLayout = textMeasurer.measure(
                text = valueTxt,
                style = TextStyle(
                    color = onPrimaryColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )

            val paddingPx = with(density) { 8.dp.toPx() }
            val tooltipW = max(titleLayout.size.width, valueLayout.size.width) + paddingPx * 2
            val tooltipH = (titleLayout.size.height + valueLayout.size.height) + paddingPx * 2

            val boxX = min(max(p.x - tooltipW / 2f, pad), w - pad - tooltipW)
            val boxY = min(p.y - tooltipH - 12f, h - pad - tooltipH)

            val tooltipRect = Rect(
                left = boxX,
                top = boxY,
                right = boxX + tooltipW,
                bottom = boxY + tooltipH
            )
            drawRoundRect(
                color = tooltipPointColor, // Usa a cor do ponto selecionado para o tooltip
                topLeft = Offset(tooltipRect.left, tooltipRect.top),
                size = tooltipRect.size,
                cornerRadius = CornerRadius(14f, 14f),
                alpha = 0.98f
            )

            drawText(
                textLayoutResult = titleLayout,
                topLeft = Offset(tooltipRect.left + paddingPx, tooltipRect.top + paddingPx)
            )
            drawText(
                textLayoutResult = valueLayout,
                topLeft = Offset(
                    tooltipRect.left + paddingPx,
                    tooltipRect.top + paddingPx + titleLayout.size.height
                )
            )
        }
    }
}