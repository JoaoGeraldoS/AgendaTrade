package com.example.agendatrade.ui.components

object AppRoutes {
    const val HOME = "home_screen"
    const val TRADE_LIST = "trade_list_screen"

    const val TRADE_REGISTER = "trade_register_screen"
    const val TASK_REGISTER = "task_register_screen"
    const val TASK_LIST = "task_list_screen"
    const val ACTIVE_REGISTER = "active_register_screen"
    const val SET_BALANCE = "set_balance"
    const val MENU = "menu"
}