package com.example.agendatrade.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import com.example.agendatrade.data.models.Task

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks")
    fun getAllTask(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    fun getTaskById(id: Long): Flow<Task?>

    @Insert
    suspend fun addTask(task: Task)

    @Update
    suspend fun upTask(task: Task)

    @Delete
    suspend fun delTask(task: Task)
}