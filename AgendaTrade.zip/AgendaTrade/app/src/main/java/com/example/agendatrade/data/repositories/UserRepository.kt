package com.example.agendatrade.data.repositories

import com.example.agendatrade.data.dao.UserDao
import com.example.agendatrade.data.models.User
import com.example.agendatrade.ui.preferences.AppPreferences
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val dao: UserDao,
    private val appPreferences: AppPreferences
) {
    fun getBalance(): Flow<Double>  = dao.getUserBalance()


    suspend fun saveBalance(balance: Double) {
        val user = User(id = 1, username = appPreferences.getUserName(), balance = balance)
        dao.insertOrUpdateUser(user)
    }
}