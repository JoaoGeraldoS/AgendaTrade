package com.example.agendatrade.data.repositories

import com.example.agendatrade.data.dao.TaskDao
import com.example.agendatrade.data.models.Task
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class TaskRepository @Inject constructor (private val dao: TaskDao) {
    fun readAllTask(): Flow<List<Task>> = dao.getAllTask()
    fun getTaskById(id: Long): Flow<Task?> = dao.getTaskById(id)
    suspend fun createTask(task: Task) = dao.addTask(task = task)
    suspend fun updateTask(task: Task) = dao.upTask(task = task)
    suspend fun deleteTask(task: Task) = dao.delTask(task = task)
}