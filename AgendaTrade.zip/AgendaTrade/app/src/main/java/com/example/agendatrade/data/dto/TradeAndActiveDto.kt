package com.example.agendatrade.data.dto

import androidx.room.Embedded
import androidx.room.Relation
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.models.Trade

data class TradeAndActiveDto(
    @Embedded val trade: Trade,
    @Relation(
        parentColumn = "activeId",
        entityColumn = "id",
        entity = Active::class
    )
    val active: Active
)
