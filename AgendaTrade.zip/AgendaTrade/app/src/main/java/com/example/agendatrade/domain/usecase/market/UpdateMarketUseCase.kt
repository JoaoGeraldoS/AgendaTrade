package com.example.agendatrade.domain.usecase.market

import com.example.agendatrade.data.models.Market
import com.example.agendatrade.data.repositories.ActiveRepository
import javax.inject.Inject

class UpdateMarketUseCase @Inject constructor(private val repository: ActiveRepository) {
    suspend operator fun invoke(market: Market) = repository.updateMarket(market)
}