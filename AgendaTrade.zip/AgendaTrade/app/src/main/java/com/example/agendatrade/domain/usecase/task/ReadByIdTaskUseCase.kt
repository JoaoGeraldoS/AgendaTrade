package com.example.agendatrade.domain.usecase.task

import com.example.agendatrade.data.models.Task
import com.example.agendatrade.data.repositories.TaskRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ReadByIdTaskUseCase @Inject constructor(private val repository: TaskRepository) {
    operator fun invoke(id: Long): Flow<Task?> = repository.getTaskById(id)
}