// AppPreferences.kt
package com.example.agendatrade.ui.preferences

import android.content.Context
import android.content.SharedPreferences
import javax.inject.Inject // Adicione este import
import javax.inject.Singleton // Adicione este import

@Singleton // Garante que o Hilt crie uma única instância
class AppPreferences @Inject constructor(
    private val context: Context
) {
    private val preferences: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "app_preferences"
        private const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_TRADE_PROFILE = "trade_profile"
        private const val KEY_MARKET_TYPE = "market_type"
        private const val CURRENCY_KEY = "currency_key"
    }

    fun isOnboardingCompleted(): Boolean {
        return preferences.getBoolean(KEY_ONBOARDING_COMPLETED, false)
    }

    fun setOnboardingCompleted(completed: Boolean) {
        preferences.edit().putBoolean(KEY_ONBOARDING_COMPLETED, completed).apply()
    }

    fun setCurrency(currency: String) {
        preferences.edit().putString(CURRENCY_KEY, currency).apply()
    }

    fun getCurrency(): String {
        return preferences.getString(CURRENCY_KEY, "BRL") ?: "BRL"
    }

    fun setUserName(name: String) {
        preferences.edit().putString(KEY_USER_NAME, name).apply()
    }

    fun getUserName(): String {
        return preferences.getString(KEY_USER_NAME, "Usuário") ?: "Usuário"
    }

    fun setTradeProfile(profile: String) {
        preferences.edit().putString(KEY_TRADE_PROFILE, profile).apply()
    }

    fun getTradeProfile(): String {
        return preferences.getString(KEY_TRADE_PROFILE, "Não especificado") ?: "Não especificado"
    }

    fun setMarketType(type: String) {
        preferences.edit().putString(KEY_MARKET_TYPE, type).apply()
    }

    fun getMarketType(): String {
        return preferences.getString(KEY_MARKET_TYPE, "Não especificado") ?: "Não especificado"
    }
}