package com.example.agendatrade.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.agendatrade.data.enums.MarketType

@Entity(tableName = "markets")
data class Market(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: MarketType
)
