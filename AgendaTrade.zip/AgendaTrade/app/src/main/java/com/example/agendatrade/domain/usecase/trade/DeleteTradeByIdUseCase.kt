package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.repositories.TradeRepository
import javax.inject.Inject

class DeleteTradeByIdUseCase @Inject constructor(private val repository: TradeRepository) {
    suspend operator fun invoke(tradeId: Long) = repository.deleteTradeById(tradeId)


}