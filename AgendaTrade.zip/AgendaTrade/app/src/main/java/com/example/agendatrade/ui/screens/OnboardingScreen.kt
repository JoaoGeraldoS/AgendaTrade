package com.example.agendatrade.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.agendatrade.ui.preferences.AppPreferences
import com.example.agendatrade.utils.DismissKeyboardOnOutsideClick

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    navController: NavController,
    appPreferences: AppPreferences
) {
    val context = LocalContext.current

    var userName by remember { mutableStateOf(TextFieldValue("", selection = TextRange(0))) }
    var tradeProfile by remember { mutableStateOf(TextFieldValue("", selection = TextRange(0))) }

    var marketType by remember { mutableStateOf(TextFieldValue("", selection = TextRange(0))) }

    // Estados para controlar a visibilidade sequencial dos campos
    var showNameField by remember { mutableStateOf(false) }
    var showProfileField by remember { mutableStateOf(false) }
    var showMarketField by remember { mutableStateOf(false) }
    var showButton by remember { mutableStateOf(false) }

    var currency by remember { mutableStateOf("BRL") }
    var showCurrencySelector by remember { mutableStateOf(false) }

    // Garante que o primeiro campo apareça imediatamente
    LaunchedEffect(Unit) {
        showNameField = true
    }

    Scaffold { paddingValues ->

        DismissKeyboardOnOutsideClick {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(animationSpec = tween(durationMillis = 500)),
                exit = fadeOut(animationSpec = tween(durationMillis = 500))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Bem-vindo(a) ao AgendaTrade!",
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.padding(bottom = 32.dp)
                    )

                    // Campo Nome
                    AnimatedVisibility(
                        visible = showNameField,
                        enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                        label = "Nome Field Animation"
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            BasicTextField(
                                value = userName,
                                onValueChange = { newValue ->
                                    userName = newValue
                                    if (newValue.text.isNotBlank() && !showProfileField) {
                                        showProfileField = true
                                    } else if (newValue.text.isBlank() && showProfileField) {
                                        showProfileField = false
                                        showMarketField = false
                                        showButton = false
                                    }
                                },
                                textStyle = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                singleLine = true,
                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                decorationBox = { innerTextField ->
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        if (userName.text.isEmpty()) {
                                            Text(
                                                text = "Seu Nome",
                                                style = MaterialTheme.typography.headlineSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                                )
                                            )
                                        }
                                        innerTextField()
                                        Spacer(Modifier.height(4.dp))
                                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), thickness = 1.dp)
                                    }
                                }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Campo Perfil de Trade
                    AnimatedVisibility(
                        visible = showProfileField,
                        enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                        label = "Profile Field Animation"
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            BasicTextField(
                                value = tradeProfile,
                                onValueChange = { newValue ->
                                    tradeProfile = newValue
                                    if (newValue.text.isNotBlank() && !showMarketField) {
                                        showMarketField = true
                                    } else if (newValue.text.isBlank() && showMarketField) {
                                        showMarketField = false
                                        showButton = false
                                    }
                                },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                singleLine = true,
                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                decorationBox = { innerTextField ->
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        if (tradeProfile.text.isEmpty()) {
                                            Text(
                                                text = "Seu Perfil de Trade (Ex: Day Trade, Swing Trade)",
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                                )
                                            )
                                        }
                                        innerTextField()
                                        Spacer(Modifier.height(4.dp))
                                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), thickness = 1.dp)
                                    }
                                }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Campo Tipo de Mercado
                    AnimatedVisibility(
                        visible = showMarketField,
                        enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                        label = "Market Field Animation"
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            BasicTextField(
                                value = marketType,
                                onValueChange = { newValue ->
                                    marketType = newValue
                                    if (newValue.text.isNotBlank()) {
                                        if (!showCurrencySelector) {
                                            showCurrencySelector = true
                                            // Certifique-se de que a moeda tem um valor padrão
                                            if (currency.isBlank()) {
                                                currency = "BRL"
                                            }
                                        }
                                    } else {
                                        showCurrencySelector = false
                                        showButton = false
                                    }
                                },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                singleLine = true,
                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                decorationBox = { innerTextField ->
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        if (marketType.text.isEmpty()) {
                                            Text(
                                                text = "Tipo de Mercado Principal (Ex: Ações, Criptomoedas)",
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                                )
                                            )
                                        }
                                        innerTextField()
                                        Spacer(Modifier.height(4.dp))
                                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), thickness = 1.dp)
                                    }
                                }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    AnimatedVisibility(
                        visible = showCurrencySelector,
                        enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                        label = "Currency Selector Animation"
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Selecione a Moeda",
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Column (
                                modifier = Modifier.fillMaxWidth(),

                                ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = currency == "BRL",
                                        onClick = {
                                            currency = "BRL"
                                            showButton = true // Exibe o botão ao selecionar a moeda
                                        }
                                    )
                                    Text("Real (R$)")
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = currency == "USD",
                                        onClick = {
                                            currency = "USD"
                                            showButton = true // Exibe o botão ao selecionar a moeda
                                        }
                                    )
                                    Text("Dólar (US$)")
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(32.dp))
                    // Botão "Começar"
                    AnimatedVisibility(
                        visible = showButton,
                        enter = fadeIn(animationSpec = tween(delayMillis = 200)),
                        exit = fadeOut(animationSpec = tween(delayMillis = 200)),
                        label = "Button Animation"
                    ) {
                        Button(
                            onClick = {
                                appPreferences.setUserName(userName.text.trim())
                                appPreferences.setTradeProfile(tradeProfile.text.trim())
                                appPreferences.setMarketType(marketType.text.trim())
                                appPreferences.setCurrency(currency)
                                appPreferences.setOnboardingCompleted(true)


                                navController.navigate("home_screen") {
                                    popUpTo("onboarding_screen") { inclusive = true }
                                    launchSingleTop = true
                                }
                            },
                            enabled = userName.text.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Começar!")
                        }
                    }
                }
            }
        }


    }
}

