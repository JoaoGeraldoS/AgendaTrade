package com.example.agendatrade.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agendatrade.data.models.Task
import com.example.agendatrade.ui.components.BottomNavegation
import com.example.agendatrade.ui.viewmodels.TaskViewModel
import java.text.SimpleDateFormat
import java.util.Locale


@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TaskListScreen(
    navController: NavController,
    viewModel: TaskViewModel = hiltViewModel()
) {

    val tasks by viewModel.tasks.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tarefas") },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier.clickable { navController.popBackStack() }.size(30.dp)
                    )
                }
            )
        },
        bottomBar = {
            BottomNavegation(navController = navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("task_register_screen") },
                containerColor = MaterialTheme.colorScheme.primary,
                ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "Adicionar Tarefa",
                    tint = MaterialTheme.colorScheme.onPrimary
                )

            }
        }
    ) { paddingValues ->
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Adaptive(minSize = 160.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalItemSpacing = 8.dp
        ) {
            if (tasks.isEmpty()) {
                item {
                    Text(
                        text = "Nenhuma Tarefa",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }

            items(tasks, key = { it.id }) { task ->
                TaskCard(task = task) { clickedTask ->
                    navController.navigate("task_detail_screen/${clickedTask.id}")
                }
            }
        }
    }
}

@Composable
fun TaskCard(task: Task, onClick: (Task) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .clickable { onClick(task) }
            .padding(15.dp)
    ) {
        Text(
            text = task.title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )

        if (task.description.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = task.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = "Criado em: ${SimpleDateFormat("dd/MM", Locale.getDefault()).format(task.createdAt)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
        if (task.concluded) {
            Text(
                text = "Concluída",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailScreen(
    navController: NavController, taskId: Long,
    viewModel: TaskViewModel = hiltViewModel()
) {

    LaunchedEffect(taskId) {
        viewModel.loadById(taskId)

    }

    val task by viewModel.selectedTask.collectAsState()

    var titleFieldState by remember(task) { mutableStateOf(TextFieldValue(task?.title ?: "")) }
    var descriptionFieldState by remember(task) { mutableStateOf(TextFieldValue(task?.description ?: "")) }
    var isConcluded by remember(task) { mutableStateOf(task?.concluded ?: false) }

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    var showDeleteDialog by remember { mutableStateOf(false) }

    if (task == null) {
       
        return
    }

    val saveTaskChanges: () -> Unit = {
        if(task != null) {
            val updatedTask = task!!.copy(
                title = titleFieldState.text,
                description = descriptionFieldState.text,
                concluded = isConcluded
            )
            viewModel.updateTask(updatedTask)
        }

    }

    BackHandler(onBack = {
        saveTaskChanges()
        navController.popBackStack()
    })


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 35.dp)
            .clickable(onClick = { focusManager.clearFocus() }),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween // Mantém a distribuição entre as extremidades
        ) {
            // Lado Esquerdo: Botão de Voltar
            Icon(
                Icons.Default.ArrowBack,
                contentDescription = "Voltar",
                modifier = Modifier
                    .size(30.dp)
                    .clickable {
                        saveTaskChanges()
                        navController.popBackStack()
                    }
            )

            // Lado Direito: Checkbox "Concluída" e Botão de Excluir
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp) // Espaçamento entre o Checkbox e a Lixeira
            ) {
                // Checkbox "Concluída"
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp) // Espaçamento entre Checkbox e texto/ícone
                ) {
                    Checkbox(
                        checked = isConcluded,
                        onCheckedChange = { isConcluded = it },
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Concluída",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.clickable { isConcluded = !isConcluded }
                    )
                    if (isConcluded) {
                        Icon(
                            Icons.Default.Done,
                            contentDescription = "Tarefa Concluída",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Botão de Excluir
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "Excluir Tarefa",
                    modifier = Modifier
                        .size(30.dp)
                        .clickable { showDeleteDialog = true }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Título da Tarefa
        BasicTextField(
            value = titleFieldState,
            onValueChange = { titleFieldState = it },
            textStyle = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .focusRequester(focusRequester),
            singleLine = true,
            decorationBox = { innerTextField ->
                if (titleFieldState.text.isEmpty()) {
                    Text(
                        text = "Título",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    )
                }
                innerTextField()
            }
        )

        Spacer(Modifier.height(8.dp))

        // Descrição da Tarefa
        BasicTextField(
            value = descriptionFieldState,
            onValueChange = { descriptionFieldState = it },
            textStyle = MaterialTheme.typography.bodyLarge.copy(
                color = MaterialTheme.colorScheme.onBackground
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .weight(1f),
            maxLines = Int.MAX_VALUE,
            decorationBox = { innerTextField ->
                if (descriptionFieldState.text.isEmpty()) {
                    Text(
                        text = "Descrição",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    )
                }
                innerTextField()
            }
        )

        Spacer(Modifier.height(16.dp))

        // Data de Criação (Não editável)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.End
        ) {
            Text(
                text = "Criado em: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(
                    task!!.createdAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(32.dp))
    }

    // --- AlertDialog de Confirmação de Exclusão (Mantido igual) ---
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Confirmar Exclusão") },
            text = { Text("Tem certeza que deseja excluir esta tarefa?") },
            confirmButton = {
                TextButton(onClick = {
                    if(task != null) {
                        viewModel.deleteTask(task!!)
                        navController.popBackStack()
                    }
                }) {
                    Text("Excluir")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
