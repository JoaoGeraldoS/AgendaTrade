package com.example.agendatrade.data.models

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.agendatrade.data.enums.OperationType
import com.example.agendatrade.data.enums.StatusTrade
import java.util.Date

@Entity(
    tableName = "trades",
    foreignKeys = [
//        ForeignKey(
//            entity = User::class,
//            parentColumns = ["id"],
//            childColumns = ["userId"],
//            onDelete = ForeignKey.CASCADE
//        ),
        ForeignKey(
            entity = Active::class,
            parentColumns = ["id"],
            childColumns = ["activeId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],

    indices = [Index(value = ["activeId"])]
)
data class Trade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val operationType: OperationType,
    val operationDate: Date = Date(),
    val inputPrice: Double,
    val outPrice: Double,
    val quantity: Double,
    val profitLoss: Double,
    val status: StatusTrade,
    val closeDate: Date? = null,
    val activeId: Long

)
