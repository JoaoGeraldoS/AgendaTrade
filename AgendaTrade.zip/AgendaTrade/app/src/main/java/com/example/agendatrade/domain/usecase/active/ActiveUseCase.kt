package com.example.agendatrade.domain.usecase.active

data class ActiveUseCase(
    val createActiveUseCase: CreateActiveUseCase,
    val readAllActiveAndMarketsUseCase: ReadAllActiveAndMarketsUseCase,
    val readActiveAndMarketByIdUseCase: ReadActiveAndMarketByIdUseCase,
    val readActiveByIdUseCase: ReadActiveByIdUseCase,
    val updateActiveUseCase: UpdateActiveUseCase,
    val deleteActiveUseCase: DeleteActiveUseCase,
    val populateActiveUseCase: PopulateActiveUseCase
)






