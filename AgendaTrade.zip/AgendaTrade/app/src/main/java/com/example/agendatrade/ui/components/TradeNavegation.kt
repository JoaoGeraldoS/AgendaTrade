package com.example.agendatrade.ui.components

import HomeScreen
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.agendatrade.ui.preferences.AppPreferences
import com.example.agendatrade.ui.screens.EditTradeScreen
import com.example.agendatrade.ui.screens.OnboardingScreen
import com.example.agendatrade.ui.screens.RegisterActiveScreen
import com.example.agendatrade.ui.screens.RegisterTaskScreen
import com.example.agendatrade.ui.screens.RegisterTradeScreen
import com.example.agendatrade.ui.screens.TaskDetailScreen
import com.example.agendatrade.ui.screens.TaskListScreen
import com.example.agendatrade.ui.screens.TradeDetailScreen
import com.example.agendatrade.ui.screens.TradeListScreen


@Composable

fun TradeAppNavigation(appPreferences: AppPreferences) {


    val navController = rememberNavController()
    val startDestination = remember {
        if (appPreferences.isOnboardingCompleted()) {
            "home_screen"
        } else {
            "onboarding_screen"
        }
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
        ) {
        val animationDuration = 300 // ms

        composable(
            AppRoutes.HOME,
        ) {
            HomeScreen(navController = navController, appPreferences= appPreferences)
        }

        composable(AppRoutes.TRADE_LIST) {
            TradeListScreen(navController = navController, appPreferences = appPreferences)
        }

        composable(
            AppRoutes.TRADE_REGISTER,
        ) {
            RegisterTradeScreen(navController = navController)
        }

        composable(
            AppRoutes.TASK_REGISTER,
        ) {
            RegisterTaskScreen(navController = navController)
        }

        composable(AppRoutes.TASK_LIST) {
            TaskListScreen(navController = navController)
        }

        composable(
            AppRoutes.ACTIVE_REGISTER,
        ) {
            RegisterActiveScreen(navController = navController)
        }

        composable(
            "task_detail_screen/{taskId}",
            arguments = listOf(navArgument("taskId") { type = NavType.LongType }),
        ) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getLong("taskId") ?: -1
            TaskDetailScreen(navController = navController, taskId = taskId)
        }

        composable(
            "trade_detail_screen/{tradeId}",
            arguments = listOf(navArgument("tradeId") { type = NavType.LongType }),
        ) { backStackEntry ->
            val tradeId = backStackEntry.arguments?.getLong("tradeId") ?: 0L
            TradeDetailScreen(navController = navController, tradeId = tradeId, appPreferences = appPreferences)
        }

        composable(
            "onboarding_screen",
            enterTransition = { fadeIn(animationSpec = tween(animationDuration)) },
            exitTransition = { fadeOut(animationSpec = tween(animationDuration)) }
        ) { OnboardingScreen(navController, appPreferences) }

        composable("edit_trade_screen/{tradeId}") { backStackEntry ->
            val tradeId = backStackEntry.arguments?.getString("tradeId")?.toLongOrNull()
            if (tradeId != null) {
                EditTradeScreen(navController, tradeId = tradeId)
            }
        }
    }


}