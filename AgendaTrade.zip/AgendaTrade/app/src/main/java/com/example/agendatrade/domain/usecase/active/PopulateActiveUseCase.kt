package com.example.agendatrade.domain.usecase.active

import com.example.agendatrade.data.enums.MarketType
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.repositories.ActiveRepository
import javax.inject.Inject

class PopulateActiveUseCase @Inject constructor(private val assetRepository: ActiveRepository) {

    suspend operator fun invoke(marketType: MarketType) {
        val assetsToInsert = when (marketType) {
            MarketType.FOREX -> getForexAssets()
            MarketType.STOCK -> getStockAssets()
            MarketType.FUTURES -> getFuturesAssets()
            MarketType.OPTIONS -> getOptionsAssets()
        }
        assetRepository.insertAll(assetsToInsert)
    }

    // Mantenha as funções privadas de dados aqui
    private fun getForexAssets(): List<Active> {
        return listOf(
            Active(name = "EUR/USD", marketId = 1, baseCurrency = "EUR", quoteCurrency = "USD"),
            Active(name = "USD/JPY", marketId = 1, baseCurrency = "USD", quoteCurrency = "JPY"),
            Active(name = "GBP/USD", marketId = 1, baseCurrency = "GBP", quoteCurrency = "USD"),
            Active(name = "USD/CAD", marketId = 1, baseCurrency = "USD", quoteCurrency = "CAD"),

        )
    }
    private fun getStockAssets(): List<Active> {
        return listOf(
            Active(name = "PETR4", marketId = 2, isFractionalMarket = true),
            Active(name = "VALE3", marketId = 2, isFractionalMarket = true),
            Active(name = "ITUB4", marketId = 2, isFractionalMarket = true),
            Active(name = "BBDC4", marketId = 2, isFractionalMarket = true)
        )
    }
    private fun getFuturesAssets(): List<Active> {
        return listOf(
            Active(name = "WIN$", marketId = 3, pointValue = 0.20),
            Active(name = "WDO$", marketId = 3, pointValue = 10.00),
            Active(name = "DOLFUT", marketId = 3, pointValue = 50.00)
        )
    }
    private fun getOptionsAssets(): List<Active> {  return emptyList() }
}