package com.example.agendatrade.domain.usecase.market

data class MarketUseCase(
    val createMarketUseCase: CreateMarketUseCase,
    val updateMarketUseCase: UpdateMarketUseCase,
    val deleteMarketUseCase: DeleteMarketUseCase,
    val readAllMarketUseCase: ReadAllMarketUseCase
)