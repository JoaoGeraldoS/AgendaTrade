package com.example.agendatrade.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agendatrade.data.models.Market
import com.example.agendatrade.ui.theme.customTextFieldColors
import com.example.agendatrade.ui.viewmodels.ActiveViewModel
import com.example.agendatrade.utils.DismissKeyboardOnOutsideClick
import com.example.agendatrade.utils.toFriendlyName


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterActiveScreen(
    navController: NavController,
    viewModel: ActiveViewModel = hiltViewModel()
) {
    val allMarkets by viewModel.allMarkets.collectAsState()
    var name by remember { mutableStateOf("") }
    var selectedMarket by remember { mutableStateOf<Market?>(null) }

    var marketExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(allMarkets) {
        if(allMarkets.isNotEmpty() && selectedMarket == null) {
            selectedMarket = allMarkets.first()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier.clickable { navController.popBackStack() }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { paddingValues ->

        DismissKeyboardOnOutsideClick {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // --- Campo Nome do Ativo ---
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Ativo") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = customTextFieldColors()
                )

                // --- Dropdown para Selecionar Mercado com opção de Adicionar ---
                ExposedDropdownMenuBox(
                    expanded = marketExpanded,
                    onExpandedChange = { marketExpanded = !marketExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = selectedMarket?.type?.toFriendlyName() ?: "Selecione um Mercado",
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Mercado") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = marketExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = marketExpanded,
                        onDismissRequest = { marketExpanded = false }
                    ) {
                        // Itens da lista de mercados existentes
                        allMarkets.forEach { marketOption ->
                            DropdownMenuItem(
                                text = { Text(text = marketOption.type.toFriendlyName()) },
                                onClick = {
                                    selectedMarket = marketOption
                                    marketExpanded = false
                                }
                            )
                        }

                        // Separador opcional para distinguir a opção de adicionar
                        if (allMarkets.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // --- Botão Salvar ---
                Button(
                    onClick = {
                        if (name.isNotBlank() && selectedMarket != null) {
                            // Chama o ViewModel para adicionar o Ativo
                            viewModel.addActive(
                                name = name,
                                marketId = selectedMarket!!.id
                            )
                            navController.popBackStack() // Volta para a tela anterior
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Salvar Ativo")
                }
            }
        }


    }
}
