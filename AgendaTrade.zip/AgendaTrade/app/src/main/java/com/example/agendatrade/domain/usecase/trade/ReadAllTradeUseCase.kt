package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.dto.TradeAndActiveDto
import com.example.agendatrade.data.repositories.TradeRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ReadAllTradeUseCase @Inject constructor(private val repository: TradeRepository) {
    operator fun invoke(): Flow<List<TradeAndActiveDto>> = repository.readAllTrade()
}