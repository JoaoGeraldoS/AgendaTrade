package com.example.agendatrade.ui.screens


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agendatrade.ui.viewmodels.TaskViewModel
import com.example.agendatrade.utils.DismissKeyboardOnOutsideClick


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterTaskScreen(
    navController: NavController,
    viewModel: TaskViewModel = hiltViewModel()
) {

    val tasks by viewModel.tasks.collectAsState()
    // --- MUDANÇA AQUI: Ajustando a inicialização do TextFieldValue ---
    var title by remember {
        mutableStateOf(
            TextFieldValue("", selection = TextRange(0)) // Inicia com seleção na posição 0
        )
    }
    var description by remember {
        mutableStateOf(
            TextFieldValue("", selection = TextRange(0)) // Inicia com seleção na posição 0
        )
    }
    var isConcluded by remember { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    val saveTask: () -> Unit = {
        if (title.text.isNotBlank() || description.text.isNotBlank()) {
            viewModel.addTask(
                title = title.text.trim(),
                description = description.text.trim(),
                concluded = isConcluded
            )
            navController.popBackStack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Registrar Tarefa") },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier
                            .clickable {
                                saveTask()
                                navController.popBackStack()
                            }
                            .size(30.dp)
                    )
                },
                actions = {
                    IconButton(onClick = {
                        saveTask()
                    }) {
                        Icon(Icons.Default.Done, contentDescription = "Salvar Tarefa")
                    }
                }
            )
        },
    ) { paddingValues ->
        DismissKeyboardOnOutsideClick {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .verticalScroll(rememberScrollState())
                    .clickable { focusManager.clearFocus() },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // --- Campo de Título ---
                BasicTextField(
                    value = title,
                    onValueChange = { newValue ->
                        // Ao receber uma nova alteração, garantimos que o cursor fique na posição certa
                        title = if (newValue.text.isEmpty()) {
                            newValue.copy(selection = TextRange(0)) // Se vazio, força cursor no início
                        } else {
                            newValue // Caso contrário, mantém a seleção padrão do usuário
                        }
                    },
                    textStyle = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .focusRequester(focusRequester),
                    singleLine = true,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    decorationBox = { innerTextField ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            if (title.text.isEmpty()) {
                                Text(
                                    text = "Título",
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                    )
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Spacer(Modifier.height(8.dp))

                // --- Campo de Descrição ---
                BasicTextField(
                    value = description,
                    onValueChange = { newValue ->
                        // Ao receber uma nova alteração, garantimos que o cursor fique na posição certa
                        description = if (newValue.text.isEmpty()) {
                            newValue.copy(selection = TextRange(0)) // Se vazio, força cursor no início
                        } else {
                            newValue // Caso contrário, mantém a seleção padrão do usuário
                        }
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 100.dp)
                        .padding(vertical = 8.dp),
                    maxLines = Int.MAX_VALUE,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    decorationBox = { innerTextField ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            if (description.text.isEmpty()) {
                                Text(
                                    text = "Descrição",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                    )
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Spacer(Modifier.height(16.dp))
            }
        }

    }
}
