package com.example.agendatrade.data.models

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey


@Entity(
    tableName = "actives",
    foreignKeys = [
        ForeignKey(
            entity = Market::class,
            parentColumns = ["id"],
            childColumns = ["marketId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["marketId"])]
)
data class Active(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val marketId: Long,

    // Campos para Forex (podem ser null se não for Forex)

    val baseCurrency: String? = null,
    val quoteCurrency: String? = null,

    // Campos para B3 Futuros (podem ser null se não for Futuros)
    val pointValue: Double? = null, // Ex: 0.20 para mini-índice, 10.00 para mini-dólar
    val tickSize: Double? = null,

    // Campos genéricos para B3 (Ações, Futuros, etc.)
    val isFractionalMarket: Boolean = false // Para saber se permite lotes fracionários (ações)
)
