

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import com.example.agendatrade.ui.components.AppRoutes
import com.example.agendatrade.ui.components.BottomNavegation
import com.example.agendatrade.ui.preferences.AppPreferences
import com.example.agendatrade.ui.screens.LineChart
import com.example.agendatrade.ui.screens.SetInitialBalanceScreen
import com.example.agendatrade.ui.viewmodels.TaskViewModel
import com.example.agendatrade.ui.viewmodels.TradeViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    tradeViewModel: TradeViewModel = hiltViewModel(),
    taskViewModel: TaskViewModel = hiltViewModel(),
    appPreferences: AppPreferences
) {

    val allTradesWithActive by tradeViewModel.allTradesWithActive.collectAsState()
    val allTasks by taskViewModel.tasks.collectAsState()

    val todayProfitLoss by tradeViewModel.todayProfitLoss.collectAsState()
    val currentBalance by tradeViewModel.currentAccountBalance.collectAsState()

    val chartData by tradeViewModel.dailyPerformanceChartData.collectAsState()
    var showSetBalanceDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    ),
                title = {
                    GreetingSection(appPreferences)
                },
                actions = {
                    Button(
                        onClick = { showSetBalanceDialog = true },
                        colors = ButtonDefaults.textButtonColors()
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Adicionar Banca",
                            modifier = Modifier.padding(end = 2.dp),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "Banca",
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            )
        },
        bottomBar = {
            BottomNavegation(navController = navController)
        },
    ) { innerPadding ->

        if (showSetBalanceDialog) {
            SetInitialBalanceScreen(
                tradeViewModel = tradeViewModel,
                onDismiss = { showSetBalanceDialog = false },
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.Start
                ) {

                    Text(
                        text = "Performance Hoje",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween

                    ) {

// Bloco Lucro/Prejuízo Total

                        Column {

                            var color: Color = Color(0xFF9B9B9B)
                            var isPositive: Boolean = false
                            var sign: String = ""


                            if (todayProfitLoss == 0.0) {
                                color = Color(0xFF9B9B9B)

                            } else if (todayProfitLoss >= 0) {
                                isPositive = true
                                color = Color(0xFF4CAF50)
                                sign = "+ "
                            } else {
                                Color(0xFFF44336)

                            }
                            
                            Row(verticalAlignment = Alignment.CenterVertically,) {
                                Icon(
                                    imageVector = if (isPositive) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = if (isPositive) "Lucro" else "Prejuízo",
                                    tint = color,
                                    modifier = Modifier.size(25.dp)
                                )

                                Spacer(Modifier.width(4.dp))

                                Text(
                                    text = "$sign${"%.2f".format(todayProfitLoss)}",
                                    color = color,
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 25.sp
                                )
                            }
                        }
// Bloco Saldo em Conta

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Saldo em Conta",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(Modifier.height(4.dp))

                            val balanceColor =
                                if (currentBalance >= 0) MaterialTheme.colorScheme.onSurface else Color(
                                    0xFFF44336
                                )

                            Text(
                                text = "${appPreferences.getCurrency()} ${"%.2f".format(currentBalance)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = balanceColor
                            )
                        }
                    }
                }

                Divider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                )

// --- Seção: Gráfico de Performance ---
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Gráfico de Performance",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    LineChart(
                        data = chartData,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        initialPointColor = Color.Cyan
                    )
                }

                Divider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                )

// --- Seção: Últimos Trades (Nova Seção) ---

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    ) {

                    Text(
                        text = "Últimos Trades",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )

                    val latestTradesToShow = remember(allTradesWithActive) {
                        allTradesWithActive
                            .sortedByDescending { it.trade.operationDate } // Ordena pelo campo de data da entidade Trade
                            .take(2) // Pega apenas os 2 últimos
                    }

                    if (latestTradesToShow.isEmpty()) {
                        Text(
                            text = "Nenhum trade registrado ainda. Que tal adicionar um?",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val dateFormatter = SimpleDateFormat("dd/MM", Locale.getDefault())

                        latestTradesToShow.take(2).forEach { tradeAndActiveDto ->
                            val trade = tradeAndActiveDto.trade
                            val ativoName = tradeAndActiveDto.active.name

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { navController.navigate("trade_detail_screen/${trade.id}") }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) { // Asset e Tipo
                                    Text(
                                        text = "$ativoName (${trade.operationType.toFriendlyName()})",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${trade.quantity} @ ${appPreferences.getCurrency()} " +
                                                "%.4f".format(trade.inputPrice),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(Modifier.width(8.dp))


                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = dateFormatter.format(trade.operationDate),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    val tradePlColor = if (trade.profitLoss >= 0) Color(0xFF4CAF50) else Color(0xFFF44336)
                                    val tradePlSign = if (trade.profitLoss >= 0) "+" else "-"

                                    Text(
                                        text = "$tradePlSign${"%.2f".format(trade.profitLoss)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = tradePlColor
                                    )
                                }
                            }

                            if (trade != latestTradesToShow.lastOrNull()) {
                                Divider(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 0.dp),
                                    thickness = 0.5.dp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                                )
                            }

                        }

                        if (latestTradesToShow.size > 2) {
                            Spacer(Modifier.height(8.dp))
                            TextButton(
                                onClick = {
                                    navController.navigate(AppRoutes.TRADE_LIST) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            ) {
                                Text("Ver todos os trades")
                            }

                        }

                    }

                }

                Divider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                )


// --- Seção: Próximas Tarefas ---

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    ) {
                    Text(
                        text = "Próximas Tarefas",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )
                    val recentTasksToShow = remember(allTasks) {
                        allTasks
                            .sortedByDescending { it.createdAt } // Ordena pela data de criação
                            .take(3) // Pega apenas as 3 últimas
                    }

                    if (recentTasksToShow.isEmpty()) {
                        Text(
                            text = "Nenhuma tarefa recente. Que tal adicionar uma?",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        recentTasksToShow.take(3).forEach { task ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { navController.navigate("task_detail_screen/${task.id}") }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (task.concluded) Icons.Default.CheckCircle else Icons.Default.CheckCircle,
                                    contentDescription = if (task.concluded) "Tarefa Concluída" else "Tarefa Pendente",
                                    tint = if (task.concluded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )

                                Spacer(Modifier.width(8.dp))

                                Column {
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (task.description.isNotBlank()) {
                                        Text(
                                            text = task.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis

                                        )

                                    }

                                }

                            }

                        }

                        if (recentTasksToShow.size > 3) {
                            Spacer(Modifier.height(8.dp))
                            TextButton(onClick = { navController.navigate(AppRoutes.TASK_LIST) }) {
                                Text("Ver todas as tarefas")

                            }

                        }

                    }

                }

            }

        }

    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 95.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.End
    ) {
        FloatingNav(navController = navController)
    }
}

@Composable
fun GreetingSection(appPreferences: AppPreferences) {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val userName = appPreferences.getUserName()
    val greeting = when (hour) {
        in 0..11 -> "Bom dia"
        in 12..17 -> "Boa tarde"
        else -> "Boa noite"
    }
    Text(
        text = "$greeting, $userName",
        style = MaterialTheme.typography.titleLarge,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp)
    )
}
