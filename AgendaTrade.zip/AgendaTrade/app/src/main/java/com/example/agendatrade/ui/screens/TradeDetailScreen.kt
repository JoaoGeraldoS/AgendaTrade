package com.example.agendatrade.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agendatrade.data.enums.StatusTrade
import com.example.agendatrade.ui.preferences.AppPreferences
import com.example.agendatrade.ui.viewmodels.TradeViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeDetailScreen(
    navController: NavController,
    tradeId: Long,
    viewModel: TradeViewModel = hiltViewModel(),
    appPreferences: AppPreferences
) {
    // Coleta o DTO de trade e ativo do StateFlow do ViewModel
    val tradeAndActiveDto by viewModel.selectedTrade.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()
    val context = LocalContext.current
    var showDeleteDialog by remember { mutableStateOf(false) }

    // Carrega os detalhes do trade quando a tela é criada ou o tradeId muda
    LaunchedEffect(tradeId) {
        viewModel.loadTradeDetails(tradeId)
    }

    // Observa mensagens de UI do ViewModel e exibe um Toast
    LaunchedEffect(uiMessage) {
        uiMessage?.let { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            viewModel.clearUiMessage()
        }
    }

    val trade = tradeAndActiveDto?.trade
    val active = tradeAndActiveDto?.active

    // Se o trade ainda estiver carregando ou não for encontrado
    if (trade == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()

        }
        return
    }

    // Agora que temos certeza que 'trade' não é nulo, podemos usá-lo
    val ativoName = active?.name ?: "Ativo não encontrado"

    // Formatos de data
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    // Cores para lucro/prejuízo
    val profitLossTextColor = if (trade.profitLoss >= 0) {
        Color(0xFF388E3C) // Verde escuro
    } else {
        Color(0xFFD32F2F) // Vermelho escuro
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ativoName, maxLines = 1) },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier
                            .clickable { navController.popBackStack() }
                            .size(30.dp)
                    )
                },
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Excluir Trade")
                    }
                    IconButton(onClick = {
                        navController.navigate("edit_trade_screen/$tradeId")
                    }) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Editar Trade"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = ativoName,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))

            Text(
                text = "Tipo de Operação: ${trade.operationType.toFriendlyName()}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(4.dp))

            Text(
                text = "Status: ${trade.status.toFriendlyName()}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))

            Text(
                text = "Data de Abertura: ${dateFormat.format(trade.operationDate)}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Hora de Abertura: ${timeFormat.format(trade.operationDate)}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))

            Text(
                text = "Preço de Entrada: ${appPreferences.getCurrency()}%.4f".format(trade.inputPrice),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(4.dp))

            Text(
                text = "Quantidade: ${trade.quantity}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(16.dp))

            // --- Lógica de Preço de Saída e Lucro/Prejuízo ---
            if (trade.status == StatusTrade.CLOSED) {
                // Se o trade estiver FECHADO, mostre o preço de saída e a data de fechamento
                Text(
                    text = "Preço de Saída: ${appPreferences.getCurrency()}%.4f".format(trade.outPrice),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(4.dp))
                // Exibe a data de fechamento, se existir
                trade.closeDate?.let {
                    Text(
                        text = "Data de Fechamento: ${dateFormat.format(it)}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Hora de Fechamento: ${timeFormat.format(it)}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(8.dp))
                }

                val profitLossSign = if (trade.profitLoss >= 0) "+" else ""
                Text(
                    text = "Lucro/Prejuízo: $profitLossSign%.2f".format(trade.profitLoss),
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = profitLossTextColor
                )
            } else {
                // Se o trade estiver ABERTO, mostre o campo para Preço de Saída e o botão Fechar Trade
                var outPriceInput by remember { mutableStateOf("") }

                OutlinedTextField(
                    value = outPriceInput,
                    onValueChange = { outPriceInput = it },
                    label = { Text("Preço de Saída (para fechar)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = {
                        val finalOutPrice = outPriceInput.replace(",", ".").toDoubleOrNull()
                        if (finalOutPrice != null) {
                            // Chama a função do ViewModel para fechar o trade
                            viewModel.onUserClosesTrade(trade.id, finalOutPrice)
                            // A tela será automaticamente atualizada via StateFlow trade após o update
                        } else {
                            Toast.makeText(context, "Por favor, insira um preço de saída válido.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Fechar Trade")
                }
            }
        }
    }

    // Diálogo de confirmação de exclusão
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Confirmar Exclusão") },
            text = { Text("Tem certeza que deseja excluir este trade de ${ativoName}?") },
            confirmButton = {
                Button(onClick = {

                    viewModel.deleteTradeById(trade.id)
                    showDeleteDialog = false
                    navController.popBackStack() // Volta para a lista de trades após a exclusão
                }) {
                    Text("Excluir")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}


