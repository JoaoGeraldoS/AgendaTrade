package com.example.agendatrade.domain.usecase.active

import com.example.agendatrade.data.dto.ActiveAndMarketDto
import com.example.agendatrade.data.repositories.ActiveRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ReadAllActiveAndMarketsUseCase @Inject constructor(private val repository: ActiveRepository) {
    operator fun invoke(): Flow<List<ActiveAndMarketDto>> = repository.getAllActiveAndMarket()
}