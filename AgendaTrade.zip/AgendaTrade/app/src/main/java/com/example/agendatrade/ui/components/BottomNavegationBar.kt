package com.example.agendatrade.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.agendatrade.R

@Composable
fun BottomNavegation(
    navController: NavController,
) {

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {
        NavigationBarItem(
            icon = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_home),
                    tint = MaterialTheme.colorScheme.onBackground,
                    contentDescription = "Home",
                    modifier = Modifier.size(25.dp)
                )
            },
            label = { Text("Home") },
            selected = currentRoute == AppRoutes.HOME,
            onClick = {
                navController.navigate(AppRoutes.HOME) {
                    popUpTo(navController.graph.startDestinationId) {

                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        )
        NavigationBarItem(
            icon = {
               Icon(
                   painter = painterResource(id = R.drawable.ic_trade),
                   tint = MaterialTheme.colorScheme.onBackground,
                   contentDescription = "Trade",
                   modifier = Modifier.size(30.dp)
               )
            },
            label = { Text("Trade") },
            selected = currentRoute == AppRoutes.TRADE_LIST,
            onClick = {

                navController.navigate(AppRoutes.TRADE_LIST) {
                    popUpTo(navController.graph.startDestinationId) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }

            }
        )
        NavigationBarItem(
            icon = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_task),
                    tint = MaterialTheme.colorScheme.onBackground,
                    contentDescription = "Task",
                    modifier = Modifier.size(25.dp)
                )
            },
            label = { Text("Task") },
            selected = currentRoute == AppRoutes.TASK_LIST,
            onClick = {

                navController.navigate(AppRoutes.TASK_LIST) {
                    popUpTo(navController.graph.startDestinationId) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }

            }
        )
    }
}
