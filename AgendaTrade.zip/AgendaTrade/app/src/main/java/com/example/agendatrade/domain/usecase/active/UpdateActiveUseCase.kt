package com.example.agendatrade.domain.usecase.active

import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.repositories.ActiveRepository
import javax.inject.Inject

class UpdateActiveUseCase @Inject constructor(private val repository: ActiveRepository) {
    suspend operator fun invoke(active: Active) {
        repository.updateActive(active)
    }
}