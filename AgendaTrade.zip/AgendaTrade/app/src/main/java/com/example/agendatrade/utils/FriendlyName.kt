package com.example.agendatrade.utils

import com.example.agendatrade.data.enums.MarketType

fun MarketType.toFriendlyName(): String {
    return when (this) {
        MarketType.FOREX -> "Forex"
        MarketType.STOCK -> "B3 - Ações"
        MarketType.FUTURES -> "B3 - Futuros"
        MarketType.OPTIONS -> "B3 - Opções"
        // Adicione outros tipos se tiver
    }
}