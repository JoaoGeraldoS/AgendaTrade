package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.data.repositories.TradeRepository
import javax.inject.Inject

class UpdateTradeUseCase @Inject constructor(private val repository: TradeRepository) {
    suspend operator fun invoke(trade: Trade) = repository.updateTrade(trade)
}