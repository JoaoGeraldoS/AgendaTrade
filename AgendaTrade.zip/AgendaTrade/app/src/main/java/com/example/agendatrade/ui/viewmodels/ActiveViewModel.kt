package com.example.agendatrade.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agendatrade.data.dto.ActiveAndMarketDto
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.models.Market
import com.example.agendatrade.domain.usecase.active.ActiveUseCase
import com.example.agendatrade.domain.usecase.market.MarketUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ActiveViewModel @Inject constructor(
    private val activeUseCase: ActiveUseCase,
    private val marketUseCase: MarketUseCase
) : ViewModel() {


    private val _selectedActive = MutableStateFlow<ActiveAndMarketDto?>(null)
    val selectedActive: StateFlow<ActiveAndMarketDto?> = _selectedActive.asStateFlow()

    private val _allActiveAndMarketDto = MutableStateFlow<List<ActiveAndMarketDto>>(emptyList())
    val allActiveAndMarketDto: StateFlow<List<ActiveAndMarketDto>> = _allActiveAndMarketDto.asStateFlow()

    private val _allMarkets = MutableStateFlow<List<Market>>(emptyList())
    val allMarkets: StateFlow<List<Market>> = marketUseCase.readAllMarketUseCase()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch(Dispatchers.IO) {
            activeUseCase.readAllActiveAndMarketsUseCase().collect {
                _allActiveAndMarketDto.value = it
            }
        }
    }


    fun loadActiveById(activeId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val activeAndMarket = activeUseCase.readActiveAndMarketByIdUseCase(activeId).firstOrNull()
                _selectedActive.value = activeAndMarket
        }
    }

    fun addActive(name: String, marketId: Long) {
        val active = Active(
            name = name,
            marketId = marketId
        )

        viewModelScope.launch(Dispatchers.IO) {
            activeUseCase.createActiveUseCase(active)
        }
    }

    fun updateActive(active: Active) {
        viewModelScope.launch(Dispatchers.IO) {
            activeUseCase.updateActiveUseCase(active)
        }
    }

    fun deleteActive(active: Active) {
        viewModelScope.launch(Dispatchers.IO) {
            activeUseCase.deleteActiveUseCase(active)
        }
    }


}