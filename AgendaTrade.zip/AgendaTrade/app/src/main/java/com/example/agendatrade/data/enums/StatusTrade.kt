package com.example.agendatrade.data.enums

enum class StatusTrade {
    OPEN, CLOSED;
    fun toFriendlyName(): String {
        return when (this) {
            OPEN -> "Aberta"
            CLOSED -> "Fechada"
        }
    }
}