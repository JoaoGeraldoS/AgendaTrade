package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.dto.TradeAndActiveDto
import com.example.agendatrade.data.repositories.TradeRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ReadByIdTradeUseCase @Inject constructor(private val repository: TradeRepository) {
    operator fun invoke(id: Long): Flow<TradeAndActiveDto?> = repository.readByIdTrade(id)
}