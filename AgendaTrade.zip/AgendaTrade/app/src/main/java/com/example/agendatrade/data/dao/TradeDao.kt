package com.example.agendatrade.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.agendatrade.data.dto.TradeAndActiveDto
import com.example.agendatrade.data.models.Trade
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {

    @Transaction
    @Query("SELECT * FROM trades ORDER BY operationDate DESC")
    fun getAllTradesWithActive(): Flow<List<TradeAndActiveDto>>

    @Query("SELECT * FROM trades WHERE id = :id LIMIT 1")
    fun getByIdTradesWithActive(id: Long): Flow<TradeAndActiveDto?>

    @Insert
    fun addTrade(trade: Trade)

    @Update
    suspend fun updateTrade(trade: Trade)

    @Query("DELETE FROM trades WHERE id = :tradeId")
    suspend fun deleteTradeById(tradeId: Long)

    @Delete
    fun deleteTrade(trade: Trade)


}