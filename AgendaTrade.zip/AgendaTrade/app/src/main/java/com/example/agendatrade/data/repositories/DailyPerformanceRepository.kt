package com.example.agendatrade.data.repositories

import com.example.agendatrade.data.dao.DailyPerformaceDao
import com.example.agendatrade.data.models.DailyPerformace
import kotlinx.coroutines.flow.Flow
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DailyPerformanceRepository @Inject constructor(
    private val dao: DailyPerformaceDao
) {
    suspend fun insertOrUpdateDailyPerformance(dailyPerformance: DailyPerformace) {
        dao.insertOrUpdate(dailyPerformance)
    }

    suspend fun updateDailyPerformance(dailyPerformance: DailyPerformace) {
        dao.update(dailyPerformance)
    }
    fun getAllDailyPerformance(): Flow<List<DailyPerformace>> {
        return dao.getAllDailyPerformance()
    }

    suspend fun getDailyPerformanceByExactDate(date: Date): Flow<DailyPerformace?> =
        dao.getDailyPerformanceByExactDate(date)

}