package com.example.agendatrade.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agendatrade.data.enums.OperationType
import com.example.agendatrade.data.enums.StatusTrade
import com.example.agendatrade.ui.theme.customTextFieldColors
import com.example.agendatrade.ui.viewmodels.TradeViewModel
import com.example.agendatrade.utils.DismissKeyboardOnOutsideClick
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTradeScreen(
    navController: NavController,
    tradeId: Long,
    tradeViewModel: TradeViewModel = hiltViewModel()
) {

    val tradeToEdit by tradeViewModel.getTradeAndActiveById(tradeId).collectAsState(initial = null)

    // Estados para os campos do formulário
    var operationType by remember { mutableStateOf(OperationType.BUY) }
    var inputPrice by remember { mutableStateOf("0.00") }
    var outPrice by remember { mutableStateOf("0.00") }
    var quantity by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf(StatusTrade.OPEN) }

    // Estados para os Dropdown Menus
    var operationTypeExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }

    // Preenche os estados com os dados do trade carregado
    LaunchedEffect(tradeToEdit) {
        tradeToEdit?.let { dto ->
            operationType = dto.trade.operationType
            inputPrice = dto.trade.inputPrice.toString()
            outPrice = dto.trade.outPrice.toString()
            quantity = dto.trade.quantity.toString()
            status = dto.trade.status
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier
                            .clickable { navController.popBackStack() }
                            .size(30.dp)
                    )
                }
            )
        }
    ) { paddingValues ->

        DismissKeyboardOnOutsideClick {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Campos NÃO editáveis
                if (tradeToEdit != null) {
                    TextField(
                        value = tradeToEdit!!.trade.operationDate?.let {
                            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it)
                        } ?: "",
                        onValueChange = {},
                        label = { Text("Data da Operação") },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = customTextFieldColors()
                    )
                    TextField(
                        value = tradeToEdit!!.active.name,
                        onValueChange = {},
                        label = { Text("Ativo") },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = customTextFieldColors()
                    )
                } else {
                    Text("Carregando trade...", style = MaterialTheme.typography.titleMedium)
                }


                // Tipo de Operação
                ExposedDropdownMenuBox(
                    expanded = operationTypeExpanded,
                    onExpandedChange = { operationTypeExpanded = !operationTypeExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = operationType.toFriendlyName(),
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Tipo de Operação") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = operationTypeExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = operationTypeExpanded,
                        onDismissRequest = { operationTypeExpanded = false }
                    ) {
                        OperationType.entries.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(text = selectionOption.toFriendlyName()) },
                                onClick = {
                                    operationType = selectionOption
                                    operationTypeExpanded = false
                                }
                            )
                        }
                    }
                }

                // Preço de Entrada
                TextField(
                    value = inputPrice,
                    onValueChange = { inputPrice = it },
                    label = { Text("Preço de Entrada") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customTextFieldColors()
                )

                // Preço de Saída
                TextField(
                    value = outPrice,
                    onValueChange = { outPrice = it },
                    label = { Text("Preço de Saída") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customTextFieldColors()
                )

                // Quantidade
                TextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("Quantidade") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = customTextFieldColors()
                )

                // Status
                ExposedDropdownMenuBox(
                    expanded = statusExpanded,
                    onExpandedChange = { statusExpanded = !statusExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = status.toFriendlyName(),
                        onValueChange = { /* Não permite edição direta */ },
                        readOnly = true,
                        label = { Text("Status") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = customTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = statusExpanded,
                        onDismissRequest = { statusExpanded = false }
                    ) {
                        StatusTrade.entries.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(text = selectionOption.toFriendlyName()) },
                                onClick = {
                                    status = selectionOption
                                    statusExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Botão para Salvar
                Button(
                    onClick = {
                        tradeToEdit?.let { dto ->
                            tradeViewModel.updateTrade(
                                tradeId = dto.trade.id,
                                newStatus = status,
                                newOperationType = operationType,
                                newInputPrice = inputPrice.toDoubleOrNull() ?: 0.0,
                                newOutPrice = outPrice.toDoubleOrNull() ?: 0.0,
                                newQuantity = quantity.toDoubleOrNull() ?: 0.0
                            )
                            navController.popBackStack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Salvar Alterações")
                }
            }
        }


    }
}