package com.example.agendatrade.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agendatrade.data.models.Task
import com.example.agendatrade.domain.usecase.task.TaskUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class TaskViewModel @Inject constructor(
    private val useCase: TaskUseCase
) : ViewModel() {

    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    private val _selectedTask = MutableStateFlow<Task?>(null)
    val tasks: StateFlow<List<Task>> = _tasks
    val selectedTask: StateFlow<Task?> = _selectedTask


    init {
        loadTask()
    }

    fun loadTask() {
        viewModelScope.launch {
            useCase.readTaskUseCase().collect { list ->
                _tasks.value = list
            }
        }
    }

    fun loadById(taskId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val task = useCase.readByIdTaskUseCase(taskId).firstOrNull()
            _selectedTask.value = task
        }
    }

    fun addTask(title: String, description: String, concluded: Boolean) {
        val task = Task(
            title = title,
            description = description,
            createdAt = Date(),
            concluded = concluded
        )

        viewModelScope.launch {
            useCase.addTaskUseCase(task)
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            useCase.updateTaskUseCase(task)
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            useCase.deleteTaskUseCase(task)
        }
    }
}