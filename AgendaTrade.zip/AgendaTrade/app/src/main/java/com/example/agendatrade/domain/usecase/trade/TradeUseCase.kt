package com.example.agendatrade.domain.usecase.trade

data class TradeUseCase(
    val readAllTradeUseCase: ReadAllTradeUseCase,
    val readByIdTradeUseCase: ReadByIdTradeUseCase,
    val createTradeUseCase: CreateTradeUseCase,
    val deleteTradeUseCase: DeleteTradeUseCase,
    val tradeProfitLossCalculator: TradeProfitLossCalculator,
    val closeTradeUseCase: CloseTradeUseCase,
    val deleteTradeByIdUseCase: DeleteTradeByIdUseCase,
    val updateTradeUseCase: UpdateTradeUseCase
)
