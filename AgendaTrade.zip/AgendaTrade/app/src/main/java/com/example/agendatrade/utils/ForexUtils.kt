package com.example.agendatrade.utils

import kotlin.math.pow

object ForexUtils {

    // Função para determinar as casas decimais de pip com base no nome do par
    fun getPipDecimalPlaces(pairName: String): Int {

        println("Nome do par: " + pairName)
        return when {
            pairName.endsWith("JPY") -> 2


            // Pares com JPY (ex: USD/JPY, EUR/JPY)
            // Você pode adicionar outras regras aqui se houver exceções
            // pairName == "XAU/USD" -> 2 // Ouro, por exemplo, pode ter 2 casas decimais no cálculo de "pontos"
            else -> 4 // A maioria dos outros pares de moedas (EUR/USD, GBP/USD, etc.)
        }
    }

    // Função para determinar o tamanho do contrato (geralmente padrão para Forex)
    fun getContractSize(pairName: String): Double {
        // A maioria dos pares de moedas Forex tem um tamanho de contrato padrão de 100.000 unidades
        // Se houver exceções (como o Ouro, XAU/USD), você pode adicionar um 'when' aqui
        return when (pairName) {
            // "XAU/USD" -> 100.0 // Ouro, 1 lote = 100 onças
            else -> 100_000.0
        }
    }

    // Função para calcular o valor de 1 pip para um dado par e tamanho de lote
    // Esta função é mais robusta e pode ser usada no TradeProfitLossCalculator
    fun calculatePipValuePerUnit(pairName: String): Double {
        val pipDecimalPlaces = getPipDecimalPlaces(pairName)
        val contractSize = getContractSize(pairName)

        // O valor de um pip é 10 elevado a menos o número de casas decimais do pip
        // Ex: para 4 casas, 10^-4 = 0.0001
        // Para 2 casas, 10^-2 = 0.01
        val pipValueBase = 10.0.pow(-pipDecimalPlaces.toDouble())

        // O valor de um pip depende também do tamanho do contrato.
        // Se o lote padrão é 100.000 e 1 pip é 0.0001, o valor de 1 pip por lote é 100.000 * 0.0001 = $10
        // Retornamos o valor por pip por unidade (se o cálculo de pipValue usa contractSize)
        return contractSize * pipValueBase // Isso retorna o valor de 1 pip para 1 lote padrão
    }
}