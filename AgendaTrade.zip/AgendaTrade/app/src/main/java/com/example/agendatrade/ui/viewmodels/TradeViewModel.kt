package com.example.agendatrade.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agendatrade.data.dto.TradeAndActiveDto
import com.example.agendatrade.data.enums.OperationType
import com.example.agendatrade.data.enums.StatusTrade
import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.data.repositories.UserRepository
import com.example.agendatrade.domain.usecase.trade.TradeUseCase
import com.example.agendatrade.ui.screens.ChartEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class TradeViewModel @Inject constructor(
    private val tradeUseCase: TradeUseCase,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _selectedTrade = MutableStateFlow<TradeAndActiveDto?>(null)
    val selectedTrade: StateFlow<TradeAndActiveDto?> = _selectedTrade.asStateFlow()

    val currentAccountBalance: StateFlow<Double> = userRepository.getBalance().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(3000),
        initialValue = 0.0
    )

    val allTradesWithActive: StateFlow<List<TradeAndActiveDto>> = tradeUseCase.readAllTradeUseCase()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(3000),
            initialValue = emptyList()
        )

    fun getTradeAndActiveById(tradeId: Long) = tradeUseCase.readByIdTradeUseCase(tradeId)

    fun saveInitialBalance(balance: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            userRepository.saveBalance(balance)
        }
    }

    fun addTrade(trade: Trade, closeDate: Date) {
        viewModelScope.launch(Dispatchers.IO) {
            val calculatedProfitLoss = if (trade.status == StatusTrade.CLOSED) {
               tradeUseCase.tradeProfitLossCalculator.calculateTradeProfitLoss(trade)
            } else {
                0.0
            }
            val tradeToSave = trade.copy(
                profitLoss = calculatedProfitLoss,
                closeDate = if (trade.status == StatusTrade.CLOSED) closeDate else null
            )

            tradeUseCase.createTradeUseCase(tradeToSave)

            if (tradeToSave.status == StatusTrade.CLOSED) {
                val currentBalance = userRepository.getBalance().first()

                val newBalance = currentBalance + calculatedProfitLoss

                userRepository.saveBalance(newBalance)
            }
        }
    }

    fun updateTrade(
        tradeId: Long,
        newStatus: StatusTrade,
        newOperationType: OperationType,
        newInputPrice: Double,
        newOutPrice: Double,
        newQuantity: Double
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val originalTradeDto = tradeUseCase.readByIdTradeUseCase(tradeId).firstOrNull() ?: return@launch
            val originalTrade = originalTradeDto.trade

            val updatedTrade = originalTrade.copy(
                status = newStatus,
                operationType = newOperationType,
                inputPrice = newInputPrice,
                outPrice = newOutPrice,
                quantity = newQuantity
            )

            val newProfitLoss = tradeUseCase.tradeProfitLossCalculator.calculateTradeProfitLoss(updatedTrade)

            val profitLossDifference = newProfitLoss - (originalTrade.profitLoss ?: 0.0)

            val currentBalance = userRepository.getBalance().first()
            val newBalance = currentBalance + profitLossDifference

            userRepository.saveBalance(newBalance)

            tradeUseCase.updateTradeUseCase(updatedTrade.copy(profitLoss = newProfitLoss))
        }
    }

    // Calcula o lucro/prejuízo dos trades fechados HOJE
    val todayProfitLoss: StateFlow<Double> = allTradesWithActive
        .map { tradesWithActive ->
            val calendar = Calendar.getInstance()
            calendar.time = Date()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            val startOfDay = calendar.time

            tradesWithActive
                .filter {
                    it.trade.status == StatusTrade.CLOSED &&
                            it.trade.closeDate != null && it.trade.closeDate.after(startOfDay)
                }
                .sumOf { it.trade.profitLoss }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    val dailyPerformanceChartData: StateFlow<List<ChartEntry>> =
        tradeUseCase.readAllTradeUseCase().combine(userRepository.getBalance()) { allTrades, currentBalance ->

            val closedTrades = allTrades
                .filter { it.trade.status == StatusTrade.CLOSED }
                .sortedBy { it.trade.closeDate }

            val chartEntries = mutableListOf<ChartEntry>()
            var cumulativeProfitLoss = 0.0


            chartEntries.add(ChartEntry("Início", (
                    currentBalance - closedTrades.sumOf { it.trade.profitLoss ?: 0.0 }
                    ).toFloat()))


            closedTrades.forEach { tradeAndActiveDto ->
                cumulativeProfitLoss += tradeAndActiveDto.trade.profitLoss ?: 0.0

                tradeAndActiveDto.trade.closeDate?.let { date ->
                    val dateLabel = SimpleDateFormat("dd/MM", Locale.getDefault()).format(date)
                    val chartValue = (currentBalance - closedTrades.sumOf { it.trade.profitLoss ?: 0.0 }
                            + cumulativeProfitLoss)
                    chartEntries.add(ChartEntry(dateLabel, chartValue.toFloat()))
                }
            }

            if (chartEntries.size <= 1) {
                return@combine emptyList()
            }

            chartEntries
        }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    fun clearUiMessage() {
        _uiMessage.value = null
    }


    fun loadTradeDetails(tradeId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                tradeUseCase.readByIdTradeUseCase(tradeId).collect { dto ->
                    _selectedTrade.value = dto
                }
            } catch (e: Exception) {
                _uiMessage.value = "Erro ao carregar detalhes do trade: ${e.message}"
            }
        }
    }

    fun onUserClosesTrade(tradeId: Long, finalOutPrice: Double) {
        viewModelScope.launch(Dispatchers.IO) {

            val finalProfitLoss: Double = tradeUseCase.closeTradeUseCase(tradeId, finalOutPrice)
            var currentBalance = userRepository.getBalance().first()
            currentBalance += finalProfitLoss
        }
    }

    fun deleteTradeById(tradeId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val tradeToDeleteDto = tradeUseCase.readByIdTradeUseCase(tradeId).firstOrNull() ?: run {
                    _uiMessage.value = "Erro: Trade não encontrado para exclusão."
                    return@launch
                }
                val tradeToDelete = tradeToDeleteDto.trade

                tradeUseCase.deleteTradeByIdUseCase(tradeId)

                // 3. Recalcule o saldo
                val profitLossToRemove = tradeToDelete.profitLoss ?: 0.0
                val currentBalance = userRepository.getBalance().first()
                val newBalance = currentBalance - profitLossToRemove
                userRepository.saveBalance(newBalance)


                _uiMessage.value = "Trade excluído com sucesso!"
                _selectedTrade.value = null
            } catch (e: Exception) {
                _uiMessage.value = "Erro ao excluir trade: ${e.message}"
            }
        }
    }
}
