package com.example.agendatrade.domain.usecase.task

data class TaskUseCase(
    val addTaskUseCase: AddTaskUseCase,
    val readTaskUseCase: ReadTaskUseCase,
    val readByIdTaskUseCase: ReadByIdTaskUseCase,
    val updateTaskUseCase: UpdateTaskUseCase,
    val deleteTaskUseCase: DeleteTaskUseCase
)








