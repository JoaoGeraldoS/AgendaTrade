package com.example.agendatrade.data.repositories


import com.example.agendatrade.data.dao.ActiveDao
import com.example.agendatrade.data.dto.ActiveAndMarketDto
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.models.Market
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ActiveRepository @Inject  constructor(private val dao: ActiveDao) {
    suspend fun createActive(active: Active) = dao.addActive(active)

    suspend fun insertAll(actives: List<Active>) = dao.insertAll(actives)
    suspend fun updateActive(active: Active) = dao.upActive(active)
    suspend fun deleteActive(active: Active) = dao.delActive(active)
    fun getActiveById(activeId: Long): Flow<Active?> = dao.getActiveById(activeId)


    fun getActiveAndMarketById(activeId: Long): Flow<ActiveAndMarketDto?> = dao.getActiveAndMarketById(activeId)
    fun getAllActiveAndMarket(): Flow<List<ActiveAndMarketDto>> = dao.getAllActiveAndMarket()


    // Operações para Mercado
    suspend fun createMarket(market: Market) = dao.addMarket(market)
    suspend fun updateMarket(market: Market) = dao.upMarket(market)
    suspend fun deleteMarket(market: Market) = dao.delMarket(market)
    fun getAllMarket(): Flow<List<Market>> = dao.getAllMarkets()
    fun getMarketById(id: Long): Flow<Market?> = dao.getMarketById(id)
}