package com.example.agendatrade.data.dto

import androidx.room.Embedded
import androidx.room.Relation
import com.example.agendatrade.data.models.Active
import com.example.agendatrade.data.models.Market

data class ActiveAndMarketDto(
    @Embedded val active: Active,
    @Relation(
        parentColumn =  "marketId",
        entityColumn = "id",
        entity = Market::class
    )
    val market: Market
)