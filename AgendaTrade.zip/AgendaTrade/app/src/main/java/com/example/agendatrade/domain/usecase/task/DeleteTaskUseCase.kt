package com.example.agendatrade.domain.usecase.task

import com.example.agendatrade.data.models.Task
import com.example.agendatrade.data.repositories.TaskRepository
import javax.inject.Inject

class DeleteTaskUseCase @Inject constructor (private val repository: TaskRepository) {
    suspend operator fun invoke(task: Task) {
        repository.deleteTask(task)
    }
}