package com.example.agendatrade.data.enums

enum class OperationType {
    BUY, SELL;
    fun toFriendlyName(): String {
        return when (this) {
            BUY -> "Compra"
            SELL -> "Venda"
        }
    }
}