package com.example.agendatrade.di

import android.app.Application
import androidx.room.Room
import com.example.agendatrade.data.dao.ActiveDao
import com.example.agendatrade.data.dao.MarketDao
import com.example.agendatrade.database.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import javax.inject.Provider
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @ApplicationScope
    @Provides
    @Singleton
    fun provideApplicationScope() = CoroutineScope(SupervisorJob())



    @Provides
    @Singleton
    fun provideDatabase(
        app: Application,
        activeDaoProvider: Provider<ActiveDao>,
        marketDaoProvider: Provider<MarketDao>,
        @ApplicationScope applicationScope: CoroutineScope
    ): AppDatabase {
        return Room.databaseBuilder(
            app,
            AppDatabase::class.java,
            "agenta_trade_db"
        ).fallbackToDestructiveMigration()
            .addCallback(AppDatabase.MarketDatabaseCallback(applicationScope, activeDaoProvider, marketDaoProvider))
            .build()
    }

    @Provides
    fun provideTaskDao(db: AppDatabase) = db.taskDao()

    @Provides
    fun provideActiveDao(db: AppDatabase) = db.activeDao()

    @Provides
    fun provideTradeDao(db: AppDatabase) = db.tradeDao()

    @Provides
    fun provideDailyPerformaceDao(db: AppDatabase) = db.dailyPerformaceDao()

    @Provides
    fun provideUserDao(db: AppDatabase) = db.userDao()

    @Provides
    fun provideMarketDao(db: AppDatabase) = db.marketDao()

}