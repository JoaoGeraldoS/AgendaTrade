package com.example.agendatrade.domain.usecase.trade

import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.data.repositories.TradeRepository
import javax.inject.Inject

class DeleteTradeUseCase @Inject constructor(private val repository: TradeRepository) {
    suspend operator fun invoke(trade: Trade) = repository.deleteTrade(trade)
}