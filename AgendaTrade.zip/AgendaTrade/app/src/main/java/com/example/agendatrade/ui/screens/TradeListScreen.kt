package com.example.agendatrade.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agendatrade.data.models.Trade
import com.example.agendatrade.ui.components.BottomNavegation
import com.example.agendatrade.ui.preferences.AppPreferences
import com.example.agendatrade.ui.viewmodels.TradeViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeListScreen(
    navController: NavController,
    viewModel: TradeViewModel = hiltViewModel(),
    appPreferences: AppPreferences
) {

    val allTradesWithActive by viewModel.allTradesWithActive.collectAsState()




    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Meus Trades") },
                // --- ADICIONADO: navigationIcon para voltar ---
                navigationIcon = {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        modifier = Modifier.clickable {
                            navController.popBackStack() // Volta para a tela anterior
                        }.size(30.dp)
                    )
                }
            )
        },
        bottomBar = {
            BottomNavegation(navController = navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("trade_register_screen") },
                containerColor = MaterialTheme.colorScheme.primary,
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "Adicionar Trade",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    ) { paddingValues ->


        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {

            if (allTradesWithActive.isEmpty()) {
                item {
                    Text(
                        text = "Nenhum trade",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }

            items(allTradesWithActive) { trade ->
                val ativoName = trade.active.name
                TradeCard(trade = trade.trade, ativoName = ativoName, appPreferences = appPreferences) {
                    navController.navigate("trade_detail_screen/${trade.trade.id}")
                }
            }
        }

    }
}

// --- Composable para Cada Cartão de Trade (MODIFICADA) ---
@Composable
fun TradeCard(trade: Trade, ativoName: String, appPreferences: AppPreferences, onClick: () -> Unit, ) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    // A cor será aplicada diretamente no texto, não no Card ou no background do PL
    val profitLossTextColor = if (trade.profitLoss >= 0) {
        Color(0xFF388E3C) // Verde escuro para lucro
    } else {
        Color(0xFFD32F2F) // Vermelho escuro para prejuízo
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp), // Espaço extra para o efeito de elevação do Card
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface // Cor de fundo padrão do tema, sem cores dinâmicas
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Linha superior: Ativo e Data
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    text = ativoName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = dateFormat.format(trade.operationDate),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))

            // Linha do meio: Tipo de Operação e Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    text = "Tipo: ${trade.operationType.toFriendlyName()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Status: ${trade.status.toFriendlyName()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))

            // Detalhes dos Preços e Quantidade
            Text(
                text = "Entrada: ${appPreferences.getCurrency()}%.2f".format(trade.inputPrice),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Saída: ${appPreferences.getCurrency()}%.2f".format(trade.outPrice),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Quantidade: ${trade.quantity}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(8.dp))

            // Lucro/Prejuízo (menor e sem fundo colorido)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End // Alinha à direita
            ) {
                val profitLossSign = if (trade.profitLoss >= 0) "+" else ""
                Text(
                    text = "P&L: $profitLossSign%.2f".format(trade.profitLoss), // Texto mais conciso
                    style = MaterialTheme.typography.bodySmall.copy( // Estilo menor
                        fontWeight = FontWeight.Bold // Mantenha o negrito
                    ),
                    color = profitLossTextColor, // Aplica a cor verde/vermelha diretamente no texto

                )
            }
        }
    }
}
