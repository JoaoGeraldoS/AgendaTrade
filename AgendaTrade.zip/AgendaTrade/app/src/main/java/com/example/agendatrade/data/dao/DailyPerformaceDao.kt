package com.example.agendatrade.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.agendatrade.data.models.DailyPerformace
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface DailyPerformaceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE) // Usar REPLACE para atualizar se o dia já existir
    suspend fun insertOrUpdate(dailyPerformance: DailyPerformace)

    @Query("SELECT * FROM daily_performaces WHERE date = :dateLimit ORDER BY date ASC")
    fun getDailyPerformanceFromDate(dateLimit: Date): Flow<List<DailyPerformace>>

    @Update
    suspend fun update(dailyPerformance: DailyPerformace)

    @Query("SELECT * FROM daily_performaces ORDER BY date ASC")
    fun getAllDailyPerformance(): Flow<List<DailyPerformace>>

    @Query("SELECT * FROM daily_performaces WHERE date = :date LIMIT 1")
    fun getDailyPerformanceByExactDate(date: Date): Flow<DailyPerformace?>

    @Query("DELETE FROM daily_performaces")
    suspend fun deleteAll() // Para testes ou reset
}